%% Function Name: RFCharacteristic_CPS
% Author: Ryan Chung, National Taiwan University, EE2-354, e-mail: d08941008@ntu.edu.tw; r04941128@ntu.edu.tw; b00901194@ntu.edu.tw
%
% No one is allowed using this .m file unless author's permission.
%
% Assumptions: Performance dependent mainly on Vbias
%
% Inputs:
%   List of input arguments
%
% Outputs:
%   RF Characteristic, Junction Capacitance, Junction Resistance, Effective RLGC model
%
% $Date: Aug. 30, 2020
%
% Copyright SheldonChung
% ________________________________________

function [Z0, gamma, Cj, Rj, Reff, Leff, Geff, Ceff] = RFCharacteristic_CPS (f, VR, T, sigma_elec, sigma_SOI, sigma_sub, t, a, b, t_MH, Hslab, t_BOX, t_sub, NA, ND, NAbody, NDbody, NAplus, NDplus, Wpslab, Wnslab, Wpbody, Wnbody, Wcontact, Wpplus_inner, Wnplus_inner, Wpplus_outer, Wnplus_outer, Hrib, Wrib, Wnoffset)
    %% LocalParam
    % f = LP.f;       % Hz
    % VR = LP.VR;
    % T = LP.T;
    % sigma_elec = LP.sigma_elec;
    % sigma_SOI = LP.sigma_SOI;
    % sigma_sub = LP.sigma_sub;
    % t = LP.t;
    % a = LP.a;
    % b = LP.b;
    % t_MH = LP.t_MH;
    % Hslab = LP.Hslab;
    % t_BOX = LP.t_BOX;
    % t_sub = LP.t_sub;
    % NA = LP.NA;
    % ND = LP.ND;
    % NAbody = LP.NAbody;
    % NDbody = LP.NDbody;
    % NAplus = LP.NAplus;
    % NDplus = LP.NDplus;
    % Wpslab = LP.Wpslab;
    % Wnslab = LP.Wnslab;
    % Wpbody = LP.Wpbody;
    % Wnbody = LP.Wnbody;
    % Wcontact = LP.Wcontact;
    % Wpplus_inner = LP.Wpplus_inner;
    % Wnplus_inner = LP.Wnplus_inner;
    % Wpplus_outer = LP.Wpplus_outer;
    % Wnplus_outer = LP.Wnplus_outer;
    % Hrib = LP.Hrib;
    % Wrib = LP.Wrib;
    % Wnoffset = LP.Wnoffset;
    
    %% Derived Parameters
    % Gvia = (b-a)/2 + 0.177e-6 * 2;
    Gvia = a + 0.177e-6 * 2;
    
    %% Longitudinal Current Loss
    % [Rm, L] = LongitudinalCurrentLoss_metal(f, sigma_elec, t, a, b, c);
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%% no need  %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % RL = LongitudinalCurrentLoss_other(f, sigma_sub, a);
    % Z = ((RL).^-1 + (Rm + 1i*2*pi.*f.*L).^-1).^-1;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %%%%%%%%%%%%%%%%%%%  new electrode model  %%%%%%%%%%%%%%%%%%%%%%
    % Rm = LongitudinalCurrentLoss2_Rm (f, a, b, c, t, sigma_elec);
    Rm = LongitudinalCurrentLoss2_Rm (f, (b - a)/2, (b - a)/2 + 2*a, 2*a + 3*(b-a)/2, t, sigma_elec);
    Rm = Rm * 2;        % CPW to CPS
    % L = LongitudinalCurrentLoss2_L (f, a, b, c, t, sigma_elec);
    L = LongitudinalCurrentLoss2_L (f, (b - a)/2, (b - a)/2 + 2*a, 2*a + 3*(b-a)/2, t, sigma_elec);
    L = L * 2;              % CPW to CPS
    Z = Rm + 1i*2*pi.*f.*L;
    % Z = ((RL).^-1 + (Rm + 1i*2*pi.*f.*L).^-1).^-1;
    
    %% Transverse Capacitance and Resistance
    zmatrix = [];
    
    % C_air = Capacitance_air(t_sub + t_BOX + Hrib + t_MH, a, b, c);
    C_air_CPS = Capacitance_air_CPS(t_sub + t_BOX + Hrib + t_MH, a, b);
    zmatrix = [zmatrix; 1./(1i*2*pi.*f*C_air_CPS)];
    
    % C_cladding = Capacitance_cladding(a, b, c);
    % zmatrix = [zmatrix; 1./(1i*2*pi.*f*C_cladding)];
    
    % C_ssub = Capacitance_ssub(a, t_MH, Hrib, t_BOX);
    C_ssub_CPS = Capacitance_ssub_CPS(a, b, t_MH, Hrib, t_BOX);
    % [G_sub, C_sub] = Capacitance_Conductance_sub(sigma_sub, t_sub+t_BOX+Hslab+t_MH, t_BOX+Hslab+t_MH, a, b, c);
    [G_sub_CPS, C_sub_CPS] = Capacitance_Conductance_sub_CPS(sigma_sub, t_sub+t_BOX+Hslab+t_MH, t_BOX+Hslab+t_MH, a, b);
    zmatrix = [zmatrix; 1./(1i*2*pi.*f*C_ssub_CPS) + 1./(1i*2*pi.*f*C_sub_CPS + G_sub_CPS)];
    
    % C_BOX = Capacitance_BOX(t_BOX + Hrib + t_MH, Hrib + t_MH,  a, b, c);
    C_BOX_CPS = Capacitance_BOX_CPS(t_BOX + Hrib + t_MH, Hrib + t_MH,  a, b);
    zmatrix = [zmatrix; 1./(1i*2*pi.*f*C_BOX_CPS)];
    
    % C_metalwall = Capacitance_metalwall(t, (b-a)/2);
    C_metalwall_CPS = Capacitance_metalwall_CPS(t, a);
    zmatrix = [zmatrix; 1./(1i*2*pi.*f*C_metalwall_CPS)];

    C_subl = Capacitance_subl(C_ssub_CPS, C_sub_CPS);
    zmatrix = [zmatrix; 1./(1i*2*pi.*f*C_subl)];
    
    Rj = JunctionR_Lateral(f, T, VR, NA, ND, NAbody, NDbody, NAplus, NDplus, Hrib, Wrib, Wnoffset, Wpslab, Wnslab, Wpbody, Wnbody, Wcontact, Wpplus_inner, Wnplus_inner, Hslab);
    Rj = Rj * 2;        % for CPS single-drive push-pull
    
    Cj = JunctionC_Lateral(T, VR, Hrib, Wrib, Wnoffset, NA, ND);
    Cj = Cj / 2;        % for CPS single-drive push-pull
    
    zmatrix = [zmatrix; Rj + 1./(1i*2*pi.*f*Cj)];
    
    % C_PMDr = Capacitance_PMDr(t_MH, a, b, c);
    % zmatrix = [zmatrix; 1./(1i*2*pi.*f*C_PMDr)];
    
    % C_sslab = Capacitance_sslab(t_MH, a);
    % [G_slab, C_slab] = Capacitance_Conductance_slab(sigma_SOI, t_MH+Hslab, t_MH, a, b, c);
    % zmatrix = [zmatrix; 1./(1i*2*pi.*f*C_sslab) + 1./(1i*2*pi.*f*C_slab + G_slab)];
    
    % C_slabl = Capacitance_slabl(C_slab, C_sslab);
    % zmatrix = [zmatrix; 1./(1i*2*pi.*f*C_slabl)];
    
    C_via = Capacitance_Via(t_MH, Gvia);
    zmatrix = [zmatrix; 1./(1i*2*pi.*f*C_via)];
    
    Y = sum(1./zmatrix);
    %fprintf('Y_ang = %f degree\n\n', angle(Y)*180/pi);
    
    Z0 = sqrt(Z./Y);
    gamma = sqrt(Z.*Y);
    
    Reff = real(Z); %figure; plot(f / 1e9, Reff); ylabel('Reff [ohm/m]'); xlabel('f [GHz]');
    Leff = imag(Z) ./ (2*pi*f); %figure; plot(f / 1e9, Leff); ylabel('Leff [H/m]'); xlabel('f [GHz]');
    Geff = real(Y); %figure; plot(f / 1e9, Geff); ylabel('Geff [S/m]'); xlabel('f [GHz]');
    Ceff = imag(Y) ./ (2*pi*f); %figure; plot(f / 1e9, Ceff); ylabel('Ceff [F/m]'); xlabel('f [GHz]');
    % figure; plot(f/1e9, real(Y)); ylabel('Geff [S/m]'); xlabel('f [GHz]'); grid on; grid minor;
    % figure; plot(f/1e9, imag(Y) ./ (2*pi*f)); ylabel('Ceff [F/m]'); xlabel('f [GHz]'); grid on; grid minor;
    
    %% for Rx0312 Cdc to compare
    % VR_sweep = 0:0.13:3.9;
    % Cj_VR__figureTemplate(T, VR_sweep, Hrib, Wrib, Wnoffset, NA, ND);
end

%% other subfunction
function [Rm, L] = LongitudinalCurrentLoss_metal(f, sigma_elec, t, a, b, c)
    Zi_center = ConductorInternalImpedance(f, sigma_elec, t, a, b, c, 'center');
    Zi_side = ConductorInternalImpedance(f, sigma_elec, t, a, b, c, 'side');
    L_ext = ExternalInductance(t, a, b, c);
    Li = imag(Zi_center + 0.5*Zi_side)./(2*pi.*f);
    L = L_ext + Li;
    Rm = real(Zi_center + 0.5*Zi_side);
    %%%%%%%%%%%%%%%%%%% Wrong!!!!!!!!!!! %%%%%%%%%%%%%%%%%%%%%%%%%
    % global mu0;
    % delta_elec = sqrt(1 ./ pi ./ f ./ mu0 ./ sigma_elec);
    % Rm = (t > delta_elec) .* (real(Zi_center + 0.5*Zi_side)) + (t <= delta_elec) * (1/sigma_elec / t / (a + c - b));
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end

function RL = LongitudinalCurrentLoss_other(f, sigma_sub, a)
%% Basic Const
    mu0 = 4*pi*1e-7; % [H/m]

    %% Derivation
    delta_sub = sqrt(1/pi./f/mu0/sigma_sub);
    RL = 1./sigma_sub./delta_sub/a ;
    
end

function C_air_CPS = Capacitance_air_CPS(tmax_sub, a, b)
    ep0 = 8.854187817e-12;  % [F/m]
    F_inf_CPS = GeomFac_F_inf_CPS(a, b);
    Fh_CPS = GeomFac_Fh_CPS(tmax_sub, a, b);
    C_air_CPS = ep0 * F_inf_CPS ^2 - 0.5 * ep0 * Fh_CPS;
end

function C_air = Capacitance_air(tmax_sub, a, b, c)
    ep0 = 8.854187817e-12;  % [F/m]
    F_air = GeomFac_F_layer(inf, 0.5e-6 + 0.7e-6 + 0.7e-6, a, b, c) + GeomFac_F_layer(inf, tmax_sub, a, b, c);
    C_air = 2*ep0*1*F_air;
end

% function C_cladding_CPS = Capacitance_cladding_CPS(a, b)
    % ep0 = 8.854187817e-12;  % [F/m]
    % erSiO2 = 3.9;
    % F_cladding = GeomFac_F_layer_CPS(0.5e-6 + 0.7e-6 + 0.7e-6, 0, a, b);
    % C_cladding_CPS = 0.5 * ep0 * erSiO2 * F_cladding;
% end

function C_cladding = Capacitance_cladding(a, b, c)
    ep0 = 8.854187817e-12;  % [F/m]
    erSiO2 = 3.9;
    F_cladding = GeomFac_F_layer(0.5e-6 + 0.7e-6 + 0.7e-6, 0, a, b, c);
    C_cladding = 2 * ep0 * erSiO2 * F_cladding;
end

function C_ssub_CPS = Capacitance_ssub_CPS(a, b, t_MH, Hrib, t_BOX)
    ep0 = 8.854187817e-12;  % [F/m]
    erSiO2 = 3.9; % [1]
    C_ssub_CPS = ep0 * erSiO2 * (b-a)/2 / (t_MH + Hrib + t_BOX);
end

function C_ssub = Capacitance_ssub(a, t_MH, Hrib, t_BOX)
    ep0 = 8.854187817e-12;  % [F/m]
    erSi = 11.9; % [1]
    erSiO2 = 3.9; % [1]
    C_ssub = ((ep0*erSiO2* a/t_MH)^-1 + (ep0*erSi* a/Hrib)^-1 + (ep0*erSiO2* a/t_BOX)^-1)^-1;
end

function [G_sub_CPS, C_sub_CPS] = Capacitance_Conductance_sub_CPS(sigma_sub, tmax_sub, tmin_sub, a, b)
    ep0 = 8.854187817e-12;  % [F/m]
    erSi = 11.9; % [1]
    F_sub = GeomFac_F_layer_CPS(tmax_sub, tmin_sub, a, b);
    G_sub_CPS = 2*sigma_sub * F_sub;
    C_sub_CPS = 0.5*ep0*erSi*F_sub;
end

function [G_sub, C_sub] = Capacitance_Conductance_sub(sigma_sub, tmax_sub, tmin_sub, a, b, c)
    ep0 = 8.854187817e-12;  % [F/m]
    erSi = 11.9; % [1]
    F_sub = GeomFac_F_layer(tmax_sub, tmin_sub, a, b, c);
    G_sub = 2*sigma_sub * F_sub;
    C_sub = 2*ep0*erSi*F_sub;
end

function C_subl = Capacitance_subl(C_ssub, C_sub)
    C_subl = C_sub - (C_ssub .* C_sub)./(C_ssub + C_sub);
end

function C_BOX_CPS = Capacitance_BOX_CPS(tmax_BOX, tmin_BOX, a, b)
    ep0 = 8.854187817e-12;  % [F/m]
    erSiO2 = 3.9; % [1]
    F_BOX = GeomFac_F_layer_CPS(tmax_BOX, tmin_BOX, a, b);
    C_BOX_CPS = 0.5*ep0*erSiO2*F_BOX;
end

function C_BOX = Capacitance_BOX(tmax_BOX, tmin_BOX, a, b, c)
    ep0 = 8.854187817e-12;  % [F/m]
    erSiO2 = 3.9; % [1]
    F_BOX = GeomFac_F_layer(tmax_BOX, tmin_BOX, a, b, c);
    C_BOX = 2*ep0*erSiO2*F_BOX;
end

function C_metalwall_CPS = Capacitance_metalwall_CPS(t, g)
    ep0 = 8.854187817e-12;  % [F/m]
    erSiO2 = 3.9; % [1]
    C_metalwall_CPS = ep0*erSiO2*t/g;
end

function C_metalwall = Capacitance_metalwall(t, g)
    ep0 = 8.854187817e-12;  % [F/m]
    erSiO2 = 3.9; % [1]
    C_metalwall = 2*ep0*erSiO2*t/g;
end

function Cj_VR__figureTemplate(T, VR_sweep, Hrib, Wrib, Wnoffset, NA, ND)
    % for Rx0312 Cj_figure to compare with numerical data
    Cj = @(x) JunctionC_Lateral(T, x, Hrib, Wrib, Wnoffset, NA, ND);
    Cdc = [];
    for VR = VR_sweep
        Cdc = [Cdc, Cj(VR)];
    end
    % save('.\imec_Rx0312_20200420\Cdc.mat', 'VR_sweep', 'Cdc');
    % figureTemplate(VR_sweep, Cdc, 'V_R (V)', 'C_p_n (F/m)', '.\imec_Rx0312_20200419\Cdc')
end

function figureTemplate(x, y, xlabelStr, ylabelStr, figureName, xlimVector, ylimVector)
    %% plot
    % figure('Units', 'centimeters', 'Position', [20, 10, 8, 6.486]);
    figure('Units', 'centimeters', 'Position', [20, 10, 8, 6.486]);
    set(gca, 'FontSize', 9); 

    %%
    plot(x, y, '-k', 'LineWidth', 1);
    % grid on;
    if nargin == 7
        ylim(ylimVector);
        xlim(xlimVector);
    end
    % set(gca,'YTick', [-70:5:0]);

    %%
    set(gca, 'FontWeight', 'bold', 'LineWidth', 2);

    %%
    ylabel(ylabelStr, 'fontweight', 'bold', 'FontSize', 12);
    xlabel(xlabelStr, 'fontweight', 'bold', 'FontSize', 12);
    % txt = {'applied voltage @', 'both arms ='};
    % text(1300, -50, txt, 'FontWeight', 'bold', 'FontSize', 9);
    % legend({'0V', '1V', '2V'}, 'FontSize', 9, 'Box', 'off');
%     title('V_p_p = 1.56 V');
    savefig(strcat(figureName,'.fig'));
end

function Cj = JunctionC_Lateral(T, VR, Hrib, Wrib, Wnoffset, NA, ND)
    %% Basiv const
    ep0 = 8.854187817e-12;  % [F/m]
    erSi = 11.9; % [1]
    erSiO2 = 3.9; % [1]
    
    %% Wd
    [Wd, Wdp, Wdn] = Width_depletion_lateral(T, VR, erSi, Wrib, Wnoffset, NA, ND);
    [~, Wdp_ox, Wdn_ox] = Width_depletion_lateral(T, VR, erSiO2, Wrib, Wnoffset, NA, ND);
    
    %% tn, tp of the eff. CPS
    tp = 2*Wdp_ox/pi;   tp_top = tp;
    tn = 2*Wdn_ox/pi;   tn_top = tn;
    Wdpmax = Wrib/2 + Wnoffset; Wdnmax = Wrib/2 - Wnoffset;
    
    %% 
    if Wdp == Wdpmax
        tp_top = 0;
    elseif Wdp + tp > Wdpmax
        tp_top = Wdpmax - Wdp;
    end
    
    if Wdn == Wdnmax
        tn_top = 0;
    elseif Wdn + tn > Wdnmax
        tn_top = Wdnmax - Wdn;
    end
    
    %%
    k_bot = sqrt(Wd * (Wd + tn + tp)/(Wd + tn)/(Wd + tp));
    F_bot = GeomFac_K2(k_bot);
    
    k_top = sqrt(Wd * (Wd + tn_top + tp_top)/(Wd + tn_top)/(Wd + tp_top));
    F_top = GeomFac_K2(k_top);
    
    %%
    Cideal = ep0 * erSi * Hrib/Wd;
    Cf = ep0 * erSiO2/pi * log(2*pi*Hrib/Wd);
    Ccps_top = ep0 * erSiO2 * F_top;
    Ccps_bot = ep0 * erSiO2 * F_bot;
    
    % Cj = Cideal + Cf + Ccps_top + Ccps_bot;
    Cj = Cideal + Cf;
end

function Rj = JunctionR_Lateral(f, T, VR, NA, ND, NAbody, NDbody, NAplus, NDplus, Hrib, Wrib, Wnoffset, Wpslab, Wnslab, Wpbody, Wnbody, Wcontact, Wpplus_inner, Wnplus_inner, Hslab)
    ep0 = 8.854187817e-12;  % [F/m]
    erSi = 11.9; % [1]
    [~, Wdp, Wdn] = Width_depletion_lateral(T, VR, erSi, Wrib, Wnoffset, NA, ND);
    w_rib_p = Wrib/2 + Wnoffset - Wdp;
    w_rib_n = Wrib/2 - Wnoffset - Wdn;
    
    %%
    rhop = resistivity_p(NA);
    rhon = resistivity_n(ND);
    rhopbody = resistivity_p(NAbody);
    rhonbody = resistivity_n(NDbody);
    rhopplus = resistivity_p(NAplus);
    rhonplus = resistivity_n(NDplus);
    
    %%
    % Rp = rhop./(1 + 1i*2*pi.*f*rhop*ep0*erSi) * (Wpslab/Hslab + w_rib_p/Hrib) + rhopbody./(1 + 1i*2*pi.*f*rhopbody*ep0*erSi) * (Wpbody/Hslab) + rhopplus./(1 + 1i*2*pi.*f*rhopplus*ep0*erSi) * ((Wpplus_inner + Wcontact)/Hrib);
    % Rn = rhon./(1 + 1i*2*pi.*f*rhon*ep0*erSi) * (Wnslab/Hslab + w_rib_n/Hrib) + rhonbody./(1 + 1i*2*pi.*f*rhonbody*ep0*erSi) * (Wnbody/Hslab) + rhonplus./(1 + 1i*2*pi.*f*rhonplus*ep0*erSi) * ((Wnplus_inner + Wcontact)/Hrib);
    
    % Rp = rhop * (Wpslab/Hslab) + rhopbody * (Wpbody/Hslab);     % CPW
    Rp = rhop * (Wpslab/Hslab) + rhopbody * (Wpbody/Hslab) + rhopplus * ((Wpplus_inner + 0.9e-6)/Hrib);     % CPS
    % Rn = rhon * (Wnslab/Hslab) + rhonbody * (Wnbody/Hslab);         % CPW
    Rn = rhon * (Wnslab/Hslab) + rhonbody * (Wnbody/Hslab) + rhonplus * ((Wnplus_inner + 0.9e-6)/Hrib);         % CPS
    Rj = Rp + Rn;
end

function [Wd, Wdp, Wdn] = Width_depletion_lateral(T, VR, er, Wrib, Wnoffset, NA, ND)
    %% Basic Constants
    ep0 = 8.854187817e-12;  % [F/m]
    e = 1.602176487e-19; % element charge [C]
    h = 6.62606896e-34; % Plank's constant [J-s]
    h_eV = h / e; % Plank's constant [eV-s]
    kB = 1.3806504e-23; % [J/K]
    m_0 = 9.11e-31; % electron mass [kg]
    Eg = 1.1242; % band gap for Si [eV]
           
    %%
    m_n=1.08*m_0; % Density-of-states effective mass for electrons
    m_p=1.15*m_0; % Density-of-states effective mass for holes
    Nc=2*(2*pi*m_n*(kB/e)*T/h_eV^2)^(3/2)/(e)^(3/2); % Effective Density of states for Conduction Band
    Nv=2*(2*pi*m_p*(kB/e)*T/h_eV^2)^(3/2)/(e)^(3/2); % Effective Density of states for Valence Band
    % ni=1e10*1e6;
    ni = sqrt(Nc*Nv).*exp(-Eg/(2*(kB/e)*T)); % intrinsict charge carriers in m^-3
%     ni = 5.29e19 * (T/300)^2.54 * exp(-6726/T); ni = ni*1e6;
    Vbi = kB * T/e *log(ND*NA/(ni^2));
    Neff = (NA*ND)/(NA+ND);
    Wdpmax = Wrib/2 + Wnoffset; Wdnmax = Wrib/2 - Wnoffset;
    
    Wd = sqrt(2*ep0*er*(Vbi+VR-2*kB*T/e)/(e*Neff));
    Wdp = Wd/(1+(NA/ND)^1);
    Wdn = Wd/(1+(NA/ND)^-1);
    
    if Wdp > Wdpmax
        Wdp = Wdpmax;
    end
    
    if Wdn > Wdnmax
        Wdn = Wdnmax;
    end
    
    Wd = Wdn + Wdp;
end

function C_PMDr = Capacitance_PMDr(dmax_MH, a, b, c)
    ep0 = 8.854187817e-12;  % [F/m]
    erSiO2 = 3.9; % [1]
    F_PMDr = GeomFac_F_layer(dmax_MH, 0, a, b, c);
    C_PMDr = ep0 * erSiO2 * F_PMDr;
end

function C_sslab = Capacitance_sslab(dmax_PMD, a)
    ep0 = 8.854187817e-12;  % [F/m]
    erSiO2 = 3.9; % [1]
    C_sslab = ep0 * erSiO2 * a/dmax_PMD;
end

function [G_slab, C_slab] = Capacitance_Conductance_slab(sigma_slab, dmax_slab, dmin_slab, a, b, c)
    ep0 = 8.854187817e-12;  % [F/m]
    erSi = 11.9; % [1]
    F_slab = GeomFac_F_layer(dmax_slab, dmin_slab, a, b, c);
    G_slab = sigma_slab * F_slab;
    C_slab = ep0 * erSi * F_slab;
end

function C_slabl = Capacitance_slabl(C_slab, C_sslab)
    C_slabl = C_slab - (C_slab.*C_sslab)./(C_slab+C_sslab);
end

function C_via = Capacitance_Via(Hvia, Gvia)
    ep0 = 8.854187817e-12;  % [F/m]
    erSiO2 = 3.9; % [1]
    C_via = ep0 * erSiO2 * Hvia / Gvia;
end

function Zi = ConductorInternalImpedance(f, sigma_elec, t, a, b, c, conductor_i)
    [Rsurface, delta_elec] = SurfaceResistance(f, sigma_elec);
    g = geomfact_g(f, sigma_elec, t, a, b, c);
    if strcmp(conductor_i, 'center')
        A = a * t;
        %fprintf('Zicenter\n');
    else
        A = (c-b)*t /2;
        %fprintf('Ziside\n');
    end
    Zi = (1+1i) .* Rsurface .*g .* coth((1+1i).*g.*A./delta_elec);
end

function L_ext = ExternalInductance(t, a, b, c)
    %% Basic const
    ep0 = 8.854187817e-12;  % [F/m]
    c0 = 299792458; % [m/s]
    %%
    F_inf = GeomFac_F_inf(a, b, c);
    C0 = 4 * ep0 .* (F_inf + t./(b-a));
    L_ext = 1 ./ (c0^2 .* C0);    
end

function [Rsurface, delta_elec] = SurfaceResistance(f, sigma_elec)
    mu0 = 4*pi*1e-7; % [H/m]
    delta_elec = sqrt(1./ pi ./ f / mu0 / sigma_elec);
    Rsurface = 1./(sigma_elec .* delta_elec);
end

function F_layer_CPS = GeomFac_F_layer_CPS(hmax, hmin, a, b)
    F_layer_CPS = GeomFac_Fh_CPS(hmax, a, b) - GeomFac_Fh_CPS(hmin, a, b);
end

function F_layer = GeomFac_F_layer(hmax, hmin, a, b, c)
    F_layer = GeomFac_Fh(hmax, a, b, c) - GeomFac_Fh(hmin, a, b, c);
end

function Fh_CPS = GeomFac_Fh_CPS(h, a, b)
    Fh_CPS = GeomFac_F_inf_CPS(a, b);
    if(h ~= inf)
        xa = 0.5 * a;
        xb = 0.5 * b;
        xah = sinh(pi*xa /(2*h));
        xbh = sinh(pi*xb /(2*h));
        kh = sqrt(1- (xah^2/xbh^2));
        F2_CPS = GeomFac_K2_CPS(kh);
        Fh_CPS = Fh_CPS ^2 /  F2_CPS;
    end
end

function Fh = GeomFac_Fh(h, a, b, c)
    if(h == 0)
        Fh = 0;
    elseif(h == inf)
        Fh = GeomFac_F_inf(a, b, c);
    else
        ah = sinh(pi*a/(2*h));
        bh = sinh(pi*b/(2*h));
        ch = sinh(pi*c/(2*h));        
        %% exclud the bug of the function 'ellipke' in MATLAB
         if log10(bh/ah)>10 && log10(ch/ah)>10
             kh = 1;
         else
            kh = ch / bh * sqrt((bh^2-ah^2) / (ch^2-ah^2));
         end        
        Fh = GeomFac_K2(kh);
    end
end

function F_inf_CPS = GeomFac_F_inf_CPS(a, b)
    xa = 0.5 * a;
    xb = 0.5 * b;
    k0 = sqrt(1 - (xa ./ xb).^2);
    F_inf_CPS = GeomFac_K2_CPS(k0);
end

function F_inf = GeomFac_F_inf(a, b, c)
    k0 = c./b .* sqrt((b.^2-a.^2)./(c.^2-a.^2));
    F_inf = GeomFac_K2(k0);
end

function F2_CPS = GeomFac_K2_CPS(k)
    F2 = GeomFac_K2(k);
    F2_CPS = 1 ./ F2;
end

function F2 = GeomFac_K2(k)
    F2 = zeros(size(k));
    idx_u = find(k>=0 & k<=0.5^0.5);
    if ~isempty(idx_u)
        k_u = sqrt(1-k(idx_u).^2);
        F2([idx_u]) = log(2 * (sqrt(1+k_u)+(4*k_u).^0.25) ./ (sqrt(1+k_u)-(4*k_u).^0.25)) ./ (2*pi);
    end
    idx_l = find(k>0.5^0.5 & k<=1);
    if ~isempty(idx_l)
        k_l = k(idx_l);
        F2([idx_l]) = 2*pi ./ log(2 * (sqrt(1+k_l)+(4*k_l).^0.25) ./ (sqrt(1+k_l)-(4*k_l).^0.25));
    end
end

function g = geomfact_g(f, sigma_elec, t, a, b, c)
    %% Basic const
    mu0 = 4*pi*1e-7; % [H/m]
    delta_elec=sqrt(1./(pi.*f*mu0*sigma_elec));
    % ExternalInductance(t, a, b, c)
    L_ext_delta1 = ExternalInductance(t, a, b, c) - ExternalInductance(t, a-0.5*delta_elec, b, c);
    L_ext_delta2 = ExternalInductance(t, a, b, c) - ExternalInductance(t, a, b+0.5*delta_elec, c);
    L_ext_delta3 = ExternalInductance(t, a, b, c) - ExternalInductance(t, a, b, c-0.5*delta_elec);
    L_ext_delta = 2*(L_ext_delta1 + L_ext_delta2 +L_ext_delta3);    
%     L_ext_delta = ExternalInductance(t, a, b, c) - ExternalInductance(t-0.5*delta_Al, a-0.5*delta_Al, b+0.5*delta_Al, c-0.5*delta_Al);    
    g = 1/mu0 * L_ext_delta ./ (-0.5*delta_elec);
end

function rhop = resistivity_p (pDoping)
  %% cleanroom.byu.edu/ResistivityCal, Boron I.I. doping
    M = [1E12, 14667.262500697669;...
        2e12, 7334.3074668356185;...
        3e12, 4889.927087022465;...
        4e12, 3667.7102733442443;...
        5e12, 2934.365635920998;...
        6e12, 2445.4601526215956;...
        7e12, 2096.2358218597333;...
        8e12, 1834.3131803545389;...
        9e12, 1630.5922829017052;...
        1E13, 1467.6130226932708;...
        2e13, 734.1605785943417;...
        3e13, 489.6439489075054;...
        4e13, 367.37169384563;...
        5e13, 294.00072283249114;...
        6e13, 245.08199920075117;...
        7e13, 210.13684491389827;...
        8e13, 183.92567879490377;...
        9e13, 163.53749497737368;...
        1E14, 147.2256168021463;...
        2e14, 73.79819816655328;...
        3e14, 49.30538454654703;...
        4e14, 37.051678632073724;...
        5e14, 29.6954663078232;...
        6e14, 24.788841344326187;...
        7e14, 21.282429079816335;...
        8e14, 18.651415388971305;...
        9e14, 16.604170143963735;...
        1e15, 14.965676972314505;...
        2e15, 7.579908648305307;...
        3e15, 5.109080787309241;...
        4e15, 3.8698450424845046;...
        5e15, 3.1242150676530103;...
        6e15, 2.6258280446610405;...
        7e15, 2.268957205168585;...
        8e15, 2.0006719602343748;...
        9e15, 1.7915300674070833;...
        1E16, 1.6238443702134566;...
        2e16, 0.8616982987851544;...
        3e16, 0.6007793658993279;...
        4e16, 0.4668833077437573;...
        5e16, 0.3848097488327641;...
        6e16, 0.32916413932536687;...
        7e16, 0.28887714529663105;...
        8e16, 0.25832187283212754;...
        9e16, 0.23432669984878876;...
        1E17, 0.21496536080345086;...
        2e17, 0.12511746716382996;...
        3e17, 0.09321100328175008;...
        4e17, 0.07634129495480432;...
        5e17, 0.06568624199523963;...
        6e17, 0.058237674979408;...
        7e17, 0.05267784309720679;...
        8e17, 0.04833354819073814;...
        9e17, 0.044822807002399274;...
        1E18, 0.04191163444675014;...
        2e18, 0.026966103247715024;...
        3e18, 0.02071543061160277;...
        4e18, 0.01708643063417176;...
        5e18, 0.014656473723778948;...
        6e18, 0.012892019382870181;...
        7e18, 0.01154155651659908;...
        8e18, 0.010468880767556137;...
        9e18, 0.009592965508561903;...
        1E19, 0.00886221011340648;...
        2e19, 0.005131728638834896;...
        3e19, 0.0036579869149012435;...
        4e19, 0.0028561262015310857;...
        5e19, 0.002349211020946666;...
        6e19, 0.0019989859115629813;...
        7e19, 0.0017422817628892251;...
        8e19, 0.0015459975398086781;...
        9e19, 0.00139106420123108;...
        1e20, 0.0012657019138033899;...
        2e20, 0.0006897187930032605;...
        3e20, 0.0004998786019967727;...
        4e20, 0.0004094563399566657;...
        5e20, 0.0003577783126309449;...
        6e20, 0.00032423639614114494;...
        7e20, 0.00030011836259918087;...
        8e20, 0.00028128252654560214;...
        9e20, 0.00026562246738990046;...
        1e21, 0.00025201950291479263];
    
    %% Boron I.I. doping
    doping = 1e6 * M(:,1);  % [m^-3]
    r = 0.01 * M(:,2);      % [ohm-m]
    
    %% interpl
    rhop = interp1(doping, r, pDoping);
    return
end

function rhon = resistivity_n(nDoping)
    %% cleanroom.byu.edu/ResistivityCal, Phosphorus I.I. doping
    M = [1e12, 4415.312387249216;...
        2e12, 2208.0516252889915;...
        3e12, 1472.260794813711;...
        4e12, 1104.3494534905074;...
        5e12, 883.593966403182;...
        6e12, 736.4182459153325;...
        7e12, 631.2890861537179;...
        8e12, 552.4396063742955;...
        9e12, 491.11028238255386;...
        1e13, 442.0453159585842;...
        2e13, 221.2258953366559;...
        3e13, 147.6002720150266;...
        4e13, 110.77927061797217;...
        5e13, 88.68220465551408;...
        6e13, 73.94805219339818;...
        7e13, 63.42178267013413;...
        8e13, 55.5257379731432;...
        9e13, 49.38336630535094;...
        1e14, 44.4686935514395;...
        2e14, 22.338735736616144;...
        3e14, 14.952225669892737;...
        4e14, 11.2547527654003;...
        5e14, 9.03396836755867;...
        6e14, 7.552014950229166;...
        7e14, 6.492509980307877;...
        8e14, 5.697188698869662;...
        9e14, 5.078087610023568;...
        1e15, 4.582406466925789;...
        2e15, 2.3446428190337527;...
        3e15, 1.5936188312472996;...
        4e15, 1.2159178983143852;...
        5e15, 0.9881007516938989;...
        6e15, 0.8354771661910652;...
        7e15, 0.7259555395677811;...
        8e15, 0.643452105317738;...
        9e15, 0.5790114696983483;...
        1e16, 0.527248940778915;...
        2e16, 0.29052217421980503;...
        3e16, 0.20890178710676735;...
        4e16, 0.16691593198161894;...
        5e16, 0.14107609616679467;...
        6e16, 0.12344257457228096;...
        7e16, 0.11056980467025358;...
        8e16, 0.10071498770296652;...
        9e16, 0.09289934113086042;...
        1e17, 0.08652951863165105;...
        2e17, 0.05571655256990463;...
        3e17, 0.043882899033872075;...
        4e17, 0.037276332798897575;...
        5e17, 0.03292880659958998;...
        6e17, 0.02978892208221377;...
        7e17, 0.027381574619978873;...
        8e17, 0.025457601255549075;...
        9e17, 0.02387237860989364;...
        1e18, 0.022535527511173582;...
        2e18, 0.015296376795037384;...
        3e18, 0.012046447049756204;...
        4e18, 0.010088747307958466;...
        5e18, 0.008746434208670373;...
        6e18, 0.007755106254631488;...
        7e18, 0.0069865311094907704;...
        8e18, 0.006369761891436145;...
        9e18, 0.005861872543276224;...
        1e19, 0.005435145683486666;...
        2e19, 0.0032109478254829377;...
        3e19, 0.0023085709125624998;...
        4e19, 0.0018107291820831128;...
        5e19, 0.0014930022758197375;...
        6e19, 0.001271837287890109;...
        7e19, 0.0011086827741232424;...
        8e19, 0.0009831936158292054;...
        9e19, 0.0008835852987861998;...
        1e20, 0.000802546357126152;...
        2e20, 0.00042070536404033483;...
        3e20, 0.0002859354020328652;...
        4e20, 0.0002167940227303361;...
        5e20, 0.00017466969978011874;...
        6e20, 0.00014629489974523987;...
        7e20, 0.00012587374537441188;...
        8e20, 0.00011046899716362771;...
        9e20, 0.00009843223638040267;...
        1e21, 0.000088766503533662];
    %% Phosphorus I.I. doping
    doping = 1e6 * M(:,1);
    r = 0.01 * M(:,2);

    %% interp1
    rhon = interp1(doping, r, nDoping);
    return
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  Test  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function Rm = LongitudinalCurrentLoss2_Rm (f, a, b, c, t, sigma_elec)
    mu0 = 4*pi*1e-7; % [H/m]

    %% Derived Params
    w = a;
    wg = (c-b)/2;
    s = (b-a)/2;
    omega = 2*pi.*f;
    omega_c1 = sqrt(2) * 4 / (mu0 * sigma_elec*t*w);
    omega_c2 = 8 / mu0 / sigma_elec * ((w+t)/w / t)^2;
    omega_g1 = 2 / mu0 / sigma_elec / t / wg;
    omega_g2 = 2 / mu0 / sigma_elec * ((2*wg + t) / wg / t)^2;
    Rc0 = 1 / sigma_elec / w / t;
    Rg0 = 1/2/sigma_elec/wg/t;
    [FLc, FLg, F0] = pc_GeomF (w, s, wg, t);
    Rc1 = sqrt(omega_c2 * mu0 / 2/ sigma_elec) * FLc / 4 / F0^2;
    Rg1 = sqrt(omega_g2 * mu0 / 2/ sigma_elec) * FLg/4/F0^2;
    nuc = log(Rc0/Rc1) / log(omega_c1 / omega_c2);
    nug = log(Rg0/Rg1) / log(omega_g1 / omega_g2);
    ac = Coeff_cg_a (omega_c1, omega_c2, nuc);
    ag = Coeff_cg_a (omega_g1, omega_g2, nug);
    Rc = zeros(1, length(f)); Rg = zeros(1, length(f));
    %% Rc
    idx1 = omega <= omega_c1;
    idx2 = omega > omega_c1 & omega <= omega_c2;
    idx3 = omega > omega_c2;
    Rc(idx1) = Rc0 * (1 + ac(1) * (omega(idx1)./omega_c1) .^2);
    Rc(idx2) = Rc1 * (omega(idx2) ./ omega_c2) .^nuc .* (1 + ac(2) * (omega_c1./omega(idx2)) .^2 + ac(3) *(omega(idx2)./omega_c2).^2);
    Rc(idx3) = sqrt(omega(idx3) * mu0/2/sigma_elec) * FLc / 4 / F0^2 .* (1 + ac(4) * (omega_c2 ./ (omega(idx3))) .^2);
    %% Rg
    idx1 = omega <= omega_g1;
    idx2 = omega > omega_g1 & omega <= omega_g2;
    idx3 = omega > omega_g2;
    Rg(idx1) = Rg0 * (1 + ag(1) * (omega(idx1)./omega_g1) .^2);
    Rg(idx2) = Rg1 * (omega(idx2) ./ omega_g2) .^nug .* (1 + ag(2) * (omega_g1./omega(idx2)) .^2 + ag(3) *(omega(idx2)./omega_g2).^2);
    Rg(idx3) = sqrt(omega(idx3) * mu0/2/sigma_elec) * FLg / 4 / F0^2 .* (1 + ag(4) * (omega_g2 ./ (omega(idx3))) .^2);
    Rm = Rc + Rg;
end

function L = LongitudinalCurrentLoss2_L (f, a, b, c, t, sigma_elec)
    mu0 = 4*pi*1e-7; % [H/m]

    %% anou function
    w = a;
    wg = (c-b)/2;
    s = (b-a)/2;
    gL = @(x) (1/12*t^2-1/2*x^2) * log(1 + (x/t)^2) + 1/12*x^4/t^2*log(1+(t/x)^2) - 2/3*x*t*(atan(x/t) + (x/t)^2 * atan(t/x));
    Ldc = @(w1, w2) mu0/8/pi * (4/w1^2 * gL(w1) + 1/w2^2 * (gL(w1+2*s) + gL(w1+2*w2+2*s) + 2*gL(w2) - 2*gL(w1+w2+2*s)) - 4/w1/w2 * (gL(w1+w2+s) - gL(w1+s) + gL(s) - gL(w2+s)));
    %% Derived Params
    omega = 2 * pi * f;
    [FLc, FLg, F0, F1] = pc_GeomF (w, s, wg, t);
    omega_L0 = 4 / mu0 / sigma_elec / t / wg;
    omega_L1 = 4 / mu0 / sigma_elec / t / w;
    omega_L2 = 18 / mu0 / sigma_elec / t^2;
    Le_inf = mu0 / 4 / F0;
    Ldc0 = Ldc(w, wg);
    Lz1 = Ldc(w, 3/2*w) - mu0/4 *1 / F1;
    Lz2 = sqrt(mu0 / 2 / omega_L2 / sigma_elec) * (FLc + FLg) / (4 * F0^2);
    nuz1 = log((Ldc0 - Le_inf) / Lz1) / log(omega_L0 / omega_L1);
    nuz2 = log(Lz1 / Lz2) / log(omega_L1 / omega_L2);
    aL = Coeff_L_a (w, wg, t, nuz1, nuz2, Le_inf, Ldc0);
    L = zeros(1, length(f));
    %% L
    idx1 = omega <= omega_L0;
    idx2 = omega > omega_L0 & omega <= omega_L1;
    idx3 = omega > omega_L1 & omega <= omega_L2;
    idx4 = omega > omega_L2;
    L(idx1) = Ldc0 * (1 + aL(6) * (omega(idx1) ./ omega_L0) .^2);
    L(idx2) = Le_inf + Lz1 * (omega(idx2) ./ omega_L1).^nuz1 .* (1 + aL(1) * (omega_L0 ./ omega(idx2)) .^2 + aL(2) * (omega(idx2) ./ omega_L1) .^2);
    L(idx3) = Le_inf + Lz2 * (omega(idx3) ./ omega_L2).^nuz2 .* (1 + aL(3) * (omega_L1 ./ omega(idx3)) .^2 + aL(4) * (omega(idx3) ./ omega_L2));
    L(idx4) = Le_inf + sqrt(mu0/2/w/sigma_elec) * (FLc + FLg) / (4*F0^2) *(1 + aL(5) * (omega_L2 ./ (omega(idx4))));
end

function aL = Coeff_L_a (w, wg, t, nuz1, nuz2, Le_inf, Ldc0)
    eta1 = (w/wg)^4 * nuz1 / (4 - nuz1);
    eta2 = (w/wg)^2 * nuz1 / (4 - nuz1);
    eta3 = (2*t / 9 / w)^3 * (nuz2 - 1/2) / (nuz2 +5/2);
    eta4 = (2*t/9/w) * (nuz2 + 1/2) / (nuz2 +5/2);
    a3 = (  (nuz2-nuz1) * (1+eta1) * (1-eta4)  +  4*eta2 + eta4*(1-3*eta1)) /  ((nuz1-nuz2)*(1+eta1)*(1-eta3) + 4 - eta3*(1-3*eta1));
    a2 = 1/(1+eta1) * (a3 *(1-eta3) - eta2 - eta4);
    a4 = -9/2*w/t *(eta4 + a3* eta3);
    a5 = (2*t/9/w)^2 * a3 + a4;
    a1 = nuz1 / (4-nuz1) + eta2 * a2;
    a0 = (1 - Le_inf / Ldc0) * (a1 + (w/wg)^2 * a2);
    aL = [a1, a2, a3, a4, a5, a0];
end

function a = Coeff_cg_a (omega1, omega2, nu)
    gamma = (omega1 / omega2)^2;
    a4 = (gamma * nu + 1/4*(1/2-nu) * (4-nu*(1-gamma^2)  )  ) /  ( 4 - nu - 1/4*(1/2-nu) * (4 - nu* (1-gamma^2)) );
    a3 = 1/4*(1/2-nu)*(1+a4);
    a2 = 1/gamma * (a4 - a3);
    a1 = a2 + gamma*a3;
    a = [a1, a2, a3, a4];
end

function [FLc, FLg, F0, F1] = pc_GeomF (w, s, wg, t)
    %% Derived Params
    a = w/2;
    b = w/2 +s;
    tH = t/2;
    k0 = Argument_elliptic (w, s, wg, t, 0); [K0p, E0p] = ellipke(sqrt(1 - k0^2));
    k1 = Argument_elliptic (w, s, wg, t, 1); K1 = ellipke(k1); K1p = ellipke(sqrt(1-k1^2));
    k2 = Argument_elliptic (w, s, wg, t, 2); K2 = ellipke(k2); K2p = ellipke(sqrt(1-k2^2));
    %%
    pc0 = b/2/a/(K0p)^2;
    pc1 = 1 + log(8*pi*a/(a+b)) + a / (a+b) * log(b/a);
    pc2 = pc1 - 2*a/b * (K0p)^2;
    pc3 = 2 * b^2 / a / (b+a) * E0p / K0p;
    pc4 = (b-a) / (b+a) * (log(8*pi*a / (a+b)) + a/b);
    pc5 = (b-a) / (b+a) * log(3);
    pc6 = (b-a) / (b+a) * log(24*pi*b*(a+b)/(b-a)^2) - b/(b+a) * log(b/a);
    %% FLc & FLg
    if tH <= s/2
        FLc = pc0/s * (1/(a+b) * (pi*b + b*log(8*pi*a/(a+b)) - (b-a) * log((b-a) / (b+a)) - b* log(2*tH/s))  +  tH/s * (pc1*pc3 - pc2 - b/a*pc4 + pc5 + (pc2-pc3+b/a-1-pc5) * log(2*tH/s))  +  (tH/s)^2 * (pc3*(1-3/2*pc1) + 3/2*pc1 - 2*pc2 + 1 + 3/2*b/a*pc4 - b/a*(b-a)/(b+a) + (2*pc2+pc1*(pc3-1)-b/a*pc4) * log(2*tH/s) ) );
        FLg = pc0/s * ( 1/(a+b)*(pi*a+a*log(8*pi*b/(b-a)) + b*log((b-a)/(b+a)) - a*log(2*tH/s))   +   tH/s * (a/b*pc1*pc3 + (1-a/b)*pc1 -pc2 - pc4 - pc5 + (-a/b*pc3+pc2 + a/b - 1 + pc5)*log(2*tH/s))  + (tH/s)^2 * (a/b*pc3*(1-3/2*pc1) + 3/2*a/b*pc1 - 2*pc2 + 2 - a/b + 3/2*pc4 - (b-a) / (b+a) + (2*pc2 + a/b *pc1 * (pc3 -1) - pc4) *log(2*tH/s)   )  );
    else
        FLc = 1/2/s + tH/s^2 + pc0/s * (  pi*b/(a+b)  +  1/2*pc6 + 1/8*(-pc1+pc3*(pc1+2) - b/a*pc4 - 2*(a^2 + b^2) / a / (a+b)) );
        FLg = 1/2/s + tH/s^2 + pc0/s * (pi*a/(a+b) - 1/2* pc6 + 1/8 * (-a/b*pc1 + a/b*pc3 * (pc1+2) - pc4 - 2*(a^2 + b^2)/b/(a+b) ) );
    end
    tp = tH;
    %% F0 & F1
    if tp <= s/2
        F0 = K1 / K1p + pc0 * (tp/s * (pc1 - log(2*tp/s)) + (tp/s)^2 * (1 - 3/2 * pc2 + pc2 * log(2*tp/s)));
    else
        F0 = K1 / K1p + pc0/8*(pc2+2) + tp/s;
    end
    F1 = F0 + K2 / K2p - K1 / K1p;
end

function k = Argument_elliptic (w, s, wg, t, num)
    k = w/(w+2*s);
    if num == 0
        return;
    elseif num == 1
        k = k * sqrt((1 - ((w + 2*s) / (w + 2*s + 2*wg))^2) / (1 - (w / (w + 2*s + 2*wg))^2));
        return;
    else
        k = k * sqrt((1 - ((w+2*s) / (4*w + 2*s))^2) / (1 - (w / (4*w + 2*s))^2));
        return;
    end
end
