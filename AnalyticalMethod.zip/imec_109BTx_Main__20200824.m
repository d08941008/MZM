% sunfunction: RF_analysis_all_figure, FoM_y, transmission_vs_lambda, transmission_vs_voltage......
% Author: Ryan Chung, National Taiwan University, EE2-354, e-mail: r04941128@ntu.edu.tw; b00901194@ntu.edu.tw
%
% No one is allowed using this .m file unless author's permission.
%
%
% needed function and data:
% 1. numericalData_Cband (extracted from Lumerical MODE solution)
% 2. numericalData_Oband (extracted from Lumerical MODE solution)
% 3. neff_alpha_V (numericalFolder, Wrib_sweep, Hrib_sweep, Hslab_sweep, wl_sweep, wl, Hrib, Wrib, Hslab, Wnoffset, Wpslab, Wnslab, Wpbody, Wnbody, NA, ND, NAbody, NDbody, pts, T, VR)
% 4. RFCharacteristic (f, VR, T, sigma_elec, sigma_SOI, sigma_sub, t, a, b, c, t_MH, Hslab, t_BOX, t_sub, NA, ND, NAbody, NDbody, NAplus, NDplus, Wpslab, Wnslab, Wpbody, Wnbody, Wcontact, Wpplus_inner, Wnplus_inner, Wpplus_outer, Wnplus_outer, Hrib, Wrib, Wnoffset)

%% Params
clc; clear all; close all;
caseName = 'imec_109BTx'; date = '20200824';
r_fee = 0.970794;
VBR = 1.103706;     % reverse bias, [V]
Zt = 64 / 2; % terminal impedance, [ohm]
Vpp = 2.5;
wl = 1.31e-6;   % optical wavelength, [m]
Wrib = 0.38e-6;         % rib waveguide width, [m]

Lactive = 924.45e-6;           % length of the TWE (traveling wave electrode), [m]
a = 1.525e-6;       % width of the center metal trace (source metal trace), [m]
delz = 1e-6;    % for # of points in active phase shifter diode region along propagation direction, [m]
Wpslab = 0.34e-6;       % width of the normally p-doped slab region, [m]
Wnslab = 0.255e-6;       % width of the normally n-doped slab region, [m]
Wnoffset = 0.005e-6;          % distance between pn junction and rib center, [m]
Wpbody = 1.845e-6;       % width of the intermediate p-doped slab region, [m]
Wnbody = 1.955e-6;    % width of the intermediate n-doped slab region, [m]

FSR = 20e-9;    % free space range [m]
T = 300;    % temperature, [K]
Zs = 50; % source impedance, [ohm]
sigma_elec = 5.96e7;    % conductivity of metal traces, [S/m] or [1/(ohm*m)]
sigma_SOI = 1/8.5e-2;     % conductivity of SOI unprocessed silicon [S/m]
sigma_sub = 1/12e-2;   % conductivity of substrate, [S/m]
t = 0.5e-6;       % thickness of metal traces, [m]
Wcontact = 1.8e-6;        % width of the highly p/n-doped rib contact region, [m]
Wpplus_inner = 0.235e-6;      % width of the highly p-doped rib inner region, [m]
Wpplus_outer = 0.2e-6;      % width of the highly p-doped rib outer region, [m]
Wpplus = Wpplus_inner + Wcontact + Wpplus_outer;
Wnplus_inner = 0.235e-6;      % width of the highly n-doped rib inner region, [m]
Wnplus_outer = 0.2e-6;      % width of the highly n-doped rib outer region, [m]
Wnplus = Wnplus_inner + Wcontact + Wnplus_outer;
b = round((a + 2 * (Wrib + Wpslab + Wnslab + Wpbody + Wnbody + Wpplus_inner + Wnplus_inner))/1e-9)*1e-9;      % width of inner sidewalls of the ground metal traces, [m]
% b = a + 2 * (Wrib + Wpslab + Wnslab + Wpbody + Wnbody + Wpplus_inner + Wnplus_inner);
Wgnd = 50e-6;       % width of the ground metal trace, [m]
c = b + 2 * Wgnd;     % width of outer sidewalls of the ground metal traces, [m]
t_MH = 1e-6;        % distance between metral trace lower y and rib waveguide higher y, [m]
t_BOX = 2e-6;       % depth of burried oxide, [m]
t_sub = 725e-6;     % depth of the substrate, [m]
Hrib = 0.22e-6;        % rig waveguide height, [m]
Hslab = 0.06e-6;   % height of the slab, [m]

%% Sheet Resistance and doping concentration
% Rsp = 6672; NA = Doping_p (Rsp, Hrib);
% Rsn = 2005; ND = Doping_n (Rsn, Hrib);
% Rspbody = 982; NAbody = Doping_p (Rspbody, Hslab);
% Rsnbody = 711; NDbody = Doping_n (Rsnbody, Hslab);
% Rspplus = 93; NAplus = Doping_p (Rspplus, Hrib);
% Rsnplus = 45.5; NDplus = Doping_n (Rsnplus, Hrib);
% NA = 5e23; ND = 5e23;
% NAbody = 3e25; NDbody = 3e25;
% NAplus = 3e25; NDplus = 3e25;
NA = 5e23;      % per m^3
ND = 5e23;      % per m^3
NAbody = 3e25;  % per m^3
NDbody = 3e25;  % per m^3
NAplus = 3e26;  % per m^3
NDplus = 3e26;  % per m^3

pts = 1500;   % # of points in waveguide along x direction
N = Lactive / delz;     % # of points in active phase shifter diode region along propagation direction
Vs = 12345;         % RF driving signal, doesn't matter.
f = 0.1:0.1:90.1; % GHz

%% sweep data for loading Ex
Wrib_sweep = Wrib - 0.025e-6: 0.005e-6: Wrib + 0.025e-6;
Hrib_sweep = Hrib - 0.005e-6: 0.005e-6: Hrib + 0.005e-6;
Hslab_sweep = Hslab - 0.015e-6: 0.005e-6: Hslab + 0.015e-6;
wl_sweep = wl - 40e-9: 10e-9: wl + 40e-9;
if wl == 1.31e-6
    numericalFolder = 'numericalData_Oband';
else
    numericalFolder = 'numericalData_Cband';
end

%% create figure folder
figPath = strcat(pwd, '\', caseName, '_', date, '\');
if ~exist(strcat(caseName, '_', date), 'dir') ~= 0
    mkdir(strcat(caseName, '_', date));
end


%% RF figure
[fee, gamma_fee, gammat_fee, f3dB_eo] = RF_analysis_all_figure (numericalFolder, figPath, Wrib_sweep, Hrib_sweep, Hslab_sweep, wl_sweep, wl, r_fee, f, VBR, T, sigma_elec, sigma_SOI, sigma_sub, t, a, b, c, t_MH, Hslab, t_BOX, t_sub, NA, ND, NAbody, NDbody, NAplus, NDplus, Wpslab, Wnslab, Wpbody, Wnbody, Wcontact, Wpplus_inner, Wnplus_inner, Wpplus_outer, Wnplus_outer, Hrib, Wrib, Wnoffset, Lactive, Zs, Zt, Vs, pts);

%% VpiLpi_differentialDrive_largeSignal
[VpiLpi, IL, ER, Vpp_y_ee, del_l, VpiLpi_head] = FoM_y (numericalFolder, Wrib_sweep, Hrib_sweep, Hslab_sweep, wl_sweep, VBR, Vpp, Lactive, FSR, N, wl, Hrib, Wrib, Hslab, Wnoffset, Wpslab, Wnslab, Wpbody, Wnbody, NA, ND, NAbody, NDbody, pts, T, gamma_fee, gammat_fee);

%% for Rx0312, VpiLpi_DC
% singleDrive_VpiLpi_Loss__figureMain(numericalFolder, figPath, Wrib_sweep, Hrib_sweep, Hslab_sweep, wl_sweep, wl, Hrib, Wrib, Hslab, Wnoffset, Wpslab, Wnslab, Wpbody, Wnbody, NA, ND, NAbody, NDbody, pts, T)

%% for Rx0312, VpiLpi_DD (differential drive)
% differentialDrive_VpiLpi_figureMain(numericalFolder, figPath, Wrib_sweep, Hrib_sweep, Hslab_sweep, wl_sweep, Vpp, Lactive, FSR, N, wl, Hrib, Wrib, Hslab, Wnoffset, Wpslab, Wnslab, Wpbody, Wnbody, NA, ND, NAbody, NDbody, pts, T, gamma_fee, gammat_fee)

%% print
diary(strcat(figPath, 'diary_', date, '.txt'));
fprintf('f3dB_eo = %f [GHz]\nVpiLpi = %f [V-cm]\nIL = %f [dB]\nER = %f [dB]\ndel_l = %.10f [um]\n', f3dB_eo, VpiLpi, IL, ER, del_l*1e6);
fprintf('VpiLpi_head = %f [V-cm]\n', VpiLpi_head);
diary off;


%% sub function
function transmission_vs_voltage (numericalFolder, figPath, Wrib_sweep, Hrib_sweep, Hslab_sweep, wl_sweep, Wrib, Hrib, Hslab, wl, v1, v2, v_num, color, L, FSR, Wnoffset, Wpslab, Wnslab, Wpbody, Wnbody, NA, ND, NAbody, NDbody, pts, T)
    v2_sweep = linspace(v1, v2, v_num); 
    wl_ILsweep = wl - 40e-9: 20e-9: wl + 40e-9; wl_num = length(wl_ILsweep);
    k0_sweep = 2*pi ./ wl_ILsweep;

    [~, n1] = min(abs(Wrib_sweep - Wrib));
    [~, n2] = min(abs(Hrib_sweep - Hrib));
    [~, n3] = min(abs(Hslab_sweep - Hslab));
    idxstr = num2str(n1) + "_" + num2str(n2);
    load(pwd + "\\" + numericalFolder + "\neff_channel_" + idxstr + ".mat");
    neff0 = interp1(wl_sweep, conj(neff), wl); % neff0 = conj(neff(n4));
    neff_channel_sweep = interp1(wl_sweep, conj(neff), wl_ILsweep);
    Ng = interp1(wl_sweep, real(ng), wl); % Ng = real(ng(n4));
    del_l = wl^2 / Ng / FSR;        % Extra strip waveguide length for the specific FSR
    del_l = (floor(real(neff0) * del_l / wl) + 0.25) / real(neff0) * wl;    % Corrected extra strip waveguide length for additional 90 degree phase shift
    
    idxstr = num2str(n1) + "_" + num2str(n2) + "_" + num2str(n3);
    load(pwd + "\\" + numericalFolder + "\neff_rib_" + idxstr + ".mat");
    neff_rib_sweep = interp1(wl_sweep, conj(neff), wl_ILsweep);

    alpha_rib = k0_sweep .* abs(imag(neff_rib_sweep));
    Neff1 = []; Del_alpha1 = []; Transmission = zeros(v_num, wl_num);
    
    % fixed the bias v1 @ arm1
    for i = 1:wl_num
            [neff1, del_alpha1] = neff_alpha_V (numericalFolder, Wrib_sweep, Hrib_sweep, Hslab_sweep, wl_sweep, wl_ILsweep(i), Hrib, Wrib, Hslab, Wnoffset, Wpslab, Wnslab, Wpbody, Wnbody, NA, ND, NAbody, NDbody, pts, T, v1);
            Neff1 = [Neff1, neff1];
            Del_alpha1 = [Del_alpha1, del_alpha1];
    end
    phi1 = k0_sweep .* Neff1 * L;
    alpha1 = alpha_rib +  100 * Del_alpha1 / 2;
    
    % sweep bias v2 @ arm 2
    for j = 1:v_num    % for voltage sweep
        Neff2 = []; Del_alpha2 = [];
        for i = 1:wl_num
            [neff2, del_alpha2] = neff_alpha_V (numericalFolder, Wrib_sweep, Hrib_sweep, Hslab_sweep, wl_sweep, wl_ILsweep(i), Hrib, Wrib, Hslab, Wnoffset, Wpslab, Wnslab, Wpbody, Wnbody, NA, ND, NAbody, NDbody, pts, T, v2_sweep(j));
            Neff2 = [Neff2, neff2];
            Del_alpha2 = [Del_alpha2, del_alpha2];
        end     % for wavelength sweep
        phi2 = k0_sweep .* Neff2 * L;
        alpha2 = alpha_rib +  100* Del_alpha2 / 2;
        
        E2 = 1 / sqrt(2) * exp(-1i * phi2 - alpha2 * L - 1i * k0_sweep .* neff_channel_sweep * del_l);
        E1 = 1 / sqrt(2) * exp(-1i * phi1 - alpha1 * L);
        Eo = 1 / sqrt(2) * (E1 + E2);
        Transmission(j, :) = abs(Eo) .^2;
    end       % for voltage sweep
    T_dB = 10 * log10(Transmission);
    
    % plot
    figure; hold on; %grid on; grid minor;
    for i = 1: wl_num
        plot(v2_sweep, Transmission(:, i), color(i)); 
    end
    hold off;
    xlabel('Voltage (V)'); ylabel('Transmission');
    savefig(strcat(figPath, 'Transmission_voltage.fig'));
    
    figure; hold on; %grid on; grid minor;
    for i = 1: wl_num
        plot(v2_sweep, T_dB(:, i), color(i)); 
    end
    hold off;
    xlabel('Voltage(V)'); ylabel('Transmission (dB)');
    savefig(strcat(figPath, 'Transmission_dB_voltage.fig'));
end

function transmission_vs_lambda (numericalFolder, figPath, Wrib_sweep, Hrib_sweep, Hslab_sweep, wl_sweep, Wrib, Hrib, Hslab, wl, v1, v2, v_num, color, L, FSR, Wnoffset, Wpslab, Wnslab, Wpbody, Wnbody, NA, ND, NAbody, NDbody, pts, T)
    v2_sweep = linspace(v1, v2, v_num); 
    wl_ILsweep = wl - 40e-9: 0.05e-9: wl + 40e-9; wl_num = length(wl_ILsweep);
    k0_sweep = 2*pi ./ wl_ILsweep;

    [~, n1] = min(abs(Wrib_sweep - Wrib));
    [~, n2] = min(abs(Hrib_sweep - Hrib));
    [~, n3] = min(abs(Hslab_sweep - Hslab));
    idxstr = num2str(n1) + "_" + num2str(n2);
    load(pwd + "\\" + numericalFolder + "\neff_channel_" + idxstr + ".mat");
    neff0 = interp1(wl_sweep, conj(neff), wl); % neff0 = conj(neff(n4));
    neff_channel_sweep = interp1(wl_sweep, conj(neff), wl_ILsweep);
    Ng = interp1(wl_sweep, real(ng), wl); % Ng = real(ng(n4));
    del_l = wl^2 / Ng / FSR;        % Extra strip waveguide length for the specific FSR
    del_l = (floor(real(neff0) * del_l / wl) + 0.25) / real(neff0) * wl;    % Corrected extra strip waveguide length for additional 90 degree phase shift
    
    idxstr = num2str(n1) + "_" + num2str(n2) + "_" + num2str(n3);
    load(pwd + "\\" + numericalFolder + "\neff_rib_" + idxstr + ".mat");
    neff_rib_sweep = interp1(wl_sweep, conj(neff), wl_ILsweep);

    alpha_rib = k0_sweep .* abs(imag(neff_rib_sweep));
    Neff1 = []; Del_alpha1 = []; Transmission = zeros(v_num, wl_num);
    
    % fixed the bias v1 @ arm1
    for i = 1:wl_num
            [neff1, del_alpha1] = neff_alpha_V (numericalFolder, Wrib_sweep, Hrib_sweep, Hslab_sweep, wl_sweep, wl_ILsweep(i), Hrib, Wrib, Hslab, Wnoffset, Wpslab, Wnslab, Wpbody, Wnbody, NA, ND, NAbody, NDbody, pts, T, v1);
            Neff1 = [Neff1, neff1];
            Del_alpha1 = [Del_alpha1, del_alpha1];
    end
    phi1 = k0_sweep .* Neff1 * L;
    alpha1 = alpha_rib +  100 * Del_alpha1 / 2;
    
    % sweep bias v2 @ arm 2
    for j = 1:v_num    % for voltage sweep
        Neff2 = []; Del_alpha2 = [];
        for i = 1:wl_num
            [neff2, del_alpha2] = neff_alpha_V (numericalFolder, Wrib_sweep, Hrib_sweep, Hslab_sweep, wl_sweep, wl_ILsweep(i), Hrib, Wrib, Hslab, Wnoffset, Wpslab, Wnslab, Wpbody, Wnbody, NA, ND, NAbody, NDbody, pts, T, v2_sweep(j));
            Neff2 = [Neff2, neff2];
            Del_alpha2 = [Del_alpha2, del_alpha2];
        end     % for wavelength sweep
        phi2 = k0_sweep .* Neff2 * L;
        alpha2 = alpha_rib +  100* Del_alpha2 / 2;
        
        E2 = 1 / sqrt(2) * exp(-1i * phi2 - alpha2 * L - 1i * k0_sweep .* neff_channel_sweep * del_l);
        E1 = 1 / sqrt(2) * exp(-1i * phi1 - alpha1 * L);
        Eo = 1 / sqrt(2) * (E1 + E2);
        Transmission(j, :) = abs(Eo) .^2;
    end       % for voltage sweep
    T_dB = 10 * log10(Transmission);
    
    % plot
    figure; hold on; %grid on; grid minor;
    for j = 1: v_num
        plot(wl_ILsweep * 1e9, Transmission(j, :), color(j)); 
    end
    hold off;
    xlabel('Wavelength (nm)'); ylabel('Transmission');
    savefig(strcat(figPath, 'Transmission.fig'));
    
    figure; hold on; %grid on; grid minor;
    for j = 1: v_num
        plot(wl_ILsweep * 1e9, T_dB(j, :), color(j)); 
    end
    hold off;
    xlabel('Wavelength (nm)'); ylabel('Transmission (dB)');
    savefig(strcat(figPath, 'Transmission_dB.fig'));
end

function [fee, gamma_fee, gammat_fee, f3dB_eo, SEE11_dB] = RF_analysis_all_figure (numericalFolder, figPath, Wrib_sweep, Hrib_sweep, Hslab_sweep, wl_sweep, wl, r_fee, f, VBR, T, sigma_elec, sigma_SOI, sigma_sub, t, a, b, c, t_MH, Hslab, t_BOX, t_sub, NA, ND, NAbody, NDbody, NAplus, NDplus, Wpslab, Wnslab, Wpbody, Wnbody, Wcontact, Wpplus_inner, Wnplus_inner, Wpplus_outer, Wnplus_outer, Hrib, Wrib, Wnoffset, Lactive, Zs, Zt, Vs, pts)
    [Z0, gamma, Cj, Rj, R, L, G, C] = RFCharacteristic (f .* 1e9, VBR, T, sigma_elec, sigma_SOI, sigma_sub, t, a, b, c, t_MH, Hslab, t_BOX, t_sub, NA, ND, NAbody, NDbody, NAplus, NDplus, Wpslab, Wnslab, Wpbody, Wnbody, Wcontact, Wpplus_inner, Wnplus_inner, Wpplus_outer, Wnplus_outer, Hrib, Wrib, Wnoffset);
    
    [SEE11_dB, SEE21_dB] = FindS (Z0, gamma, Lactive, Zs, Zt);
    c0 = 299792458; neffe = imag(gamma)./(2*pi.*f.*1e9./c0);
    Attenuation = 2*10/log(10) *real(gamma)/1e3; % dB/mm
    omega = 2 * pi * f .* 1e9; domega = gradient(omega);
    nge = neffe + omega.*(gradient(neffe))./(domega);
    SEO21 = EO_response (numericalFolder, Wrib_sweep, Hrib_sweep, Hslab_sweep, wl_sweep, wl, Hrib, Wrib, Hslab, Wnoffset, Wpslab, Wnslab, Wpbody, Wnbody, NA, ND, NAbody, NDbody, pts, T, f.*1e9, Z0, gamma, Cj, Rj, Zs, Zt, Lactive, Vs);
    SEO21_dB = 20*log10(abs(SEO21));
    if isnan(SEO21_dB)
        fprintf('f3dB_eo = 0.5 [GHz]\n');
        f3dB_eo = 0.5;
        fee = 0.1;
    else
        f3dB_eo = interp1(SEO21_dB, f, -3);
        fee = r_fee * f3dB_eo; 
    end
    [gamma_fee, gammat_fee] = FindParamAt_f_operation (fee*1e9, f.*1e9, Z0, gamma, Zt);
    
    %% Reff
    save(strcat(figPath, 'Reff.mat'), 'f', 'R');
    figureTemplate(f, R, 'Frequency (GHz)', 'R_e_f_f (\Omega/m)', strcat(figPath, 'Reff'));

    %% Leff
    save(strcat(figPath, 'Leff.mat'), 'f', 'L');
    figureTemplate(f, L, 'Frequency (GHz)', 'L_e_f_f (H/m)', strcat(figPath, 'Leff'));
    
    %% Geff
    save(strcat(figPath, 'Geff_loaded.mat'), 'f', 'G');
    figureTemplate(f, G, 'Frequency (GHz)', 'G_e_f_f (S/m)', strcat(figPath, 'Geff_loaded'));
    
    %% Ceff
    save(strcat(figPath, 'Ceff_loaded.mat'), 'f', 'C');
    figureTemplate(f, C, 'Frequency (GHz)', 'C_e_f_f (F/m)', strcat(figPath, 'Ceff_loaded'));
    
    %% real(Z0)
    save(strcat(figPath, 'Z0.mat'), 'f', 'Z0');
    figureTemplate(f, real(Z0), 'Frequency (GHz)', 'Re\{Z_0\} (\Omega)', strcat(figPath, 'Z0_real'));
    
    %% imag(Z0)
    figureTemplate(f, imag(Z0), 'Frequency (GHz)', 'Im\{Z_0\} (\Omega)', strcat(figPath, 'Z0_imag'));
    
    %% neffe
    save(strcat(figPath, 'neffe.mat'), 'f', 'neffe');
    figureTemplate(f, neffe, 'Frequency (GHz)', 'neff_\mu', strcat(figPath, 'neffe'));
    
    %% nge
    save(strcat(figPath, 'nge.mat'), 'f', 'nge');
    figureTemplate(f, nge, 'Frequency (GHz)', 'n_g_\mu', strcat(figPath, 'nge'));
    
    %% attenuation    
    save(strcat(figPath, 'Attenuation.mat'), 'f', 'Attenuation');
    figureTemplate(f, Attenuation, 'Frequency (GHz)', 'Attenuation (dB/mm)', strcat(figPath, 'Attenuation'));
    
    %% SEE11_dB    
    save(strcat(figPath, 'SEE11_dB.mat'), 'f', 'SEE11_dB');
    figureTemplate(f, SEE11_dB, 'Frequency (GHz)', 'S_E_E_1_1 (dB)', strcat(figPath, 'SEE11_dB'));
    
    %% SEE21_dB
    save(strcat(figPath, 'SEE21_dB.mat'), 'f', 'SEE21_dB');
    figureTemplate(f, SEE21_dB, 'Frequency (GHz)', 'S_E_E_2_1 (dB)', strcat(figPath, 'SEE21_dB'));
    
    %% SEO21_dB
    save(strcat(figPath, 'SEO21_dB.mat'), 'f', 'SEO21_dB');
    figureTemplate(f, SEO21_dB, 'Frequency (GHz)', 'S_E_O_2_1 (dB)', strcat(figPath, 'SEO21_dB'));
    
end

function singleDrive_VpiLpi_Loss__figureMain(numericalFolder, figPath, Wrib_sweep, Hrib_sweep, Hslab_sweep, wl_sweep, wl, Hrib, Wrib, Hslab, Wnoffset, Wpslab, Wnslab, Wpbody, Wnbody, NA, ND, NAbody, NDbody, pts, T)
    % for Rx0312, VpiLpi_DC
    VR_sweep = 0:0.13:3.9;
    
    [Neff1, Del_alpha1] = neff_alpha_V (numericalFolder, Wrib_sweep, Hrib_sweep, Hslab_sweep, wl_sweep, wl, Hrib, Wrib, Hslab, Wnoffset, Wpslab, Wnslab, Wpbody, Wnbody, NA, ND, NAbody, NDbody, pts, T, 0);
    
    Neff2 = []; Del_alpha2 = [];
    for VR = VR_sweep
        [neff2, del_alpha2] = neff_alpha_V (numericalFolder, Wrib_sweep, Hrib_sweep, Hslab_sweep, wl_sweep, wl, Hrib, Wrib, Hslab, Wnoffset, Wpslab, Wnslab, Wpbody, Wnbody, NA, ND, NAbody, NDbody, pts, T, VR);
        Neff2 = [Neff2, neff2];
        Del_alpha2 = [Del_alpha2, del_alpha2];
    end
    VpiLpi_DC = (wl .* 100) ./ 2 ./ (Neff2 - Neff1) .* VR_sweep;        % V-cm
    
    save(strcat(figPath, 'VpiLpi_DC.mat'), 'VR_sweep', 'VpiLpi_DC');
    figureTemplate(VR_sweep, VpiLpi_DC, 'V_R (V)', 'V\piL\pi (V-cm)', strcat(figPath, 'VpiLpi_DC'));
    
    Loss = 10 / log(10) * Del_alpha2;       % dB/cm, Del_alpha2 is already times 2, no need to * 2 for power loss calculation
    save(strcat(figPath, 'Loss.mat'), 'VR_sweep', 'Loss');
    figureTemplate(VR_sweep, Loss, 'V_R (V)', 'Optical Loss (dB/cm)', strcat(figPath, 'Loss'));
end

function differentialDrive_VpiLpi_figureMain(numericalFolder, figPath, Wrib_sweep, Hrib_sweep, Hslab_sweep, wl_sweep, Vpp, Lactive, FSR, N, wl, Hrib, Wrib, Hslab, Wnoffset, Wpslab, Wnslab, Wpbody, Wnbody, NA, ND, NAbody, NDbody, pts, T, gamma_fee, gammat_fee)
    y = linspace(0, Lactive, N); dy = gradient(y);
    VpiLpi_DD = []; VBR_sweep = 0.78:0.13:2.6;
    for VBR = VBR_sweep
        [Neff2, Neff1, Del_alpha2, Del_alpha1, Vpp_y_ee] = SSLV_FCIE (numericalFolder, Wrib_sweep, Hrib_sweep, Hslab_sweep, wl_sweep, Vpp, Lactive, y, wl, Hrib, Wrib, Hslab, Wnoffset, Wpslab, Wnslab, Wpbody, Wnbody, NA, ND, NAbody, NDbody, pts, T, gamma_fee, gammat_fee, VBR);
        VpiLpi_DD = [VpiLpi_DD, Vpp * Lactive * (wl * 100) / 2 / sum((Neff2 - Neff1) .* dy)];       % V-cm
    end
    save(strcat(figPath, 'VpiLpi_DD.mat'), 'VBR_sweep', 'VpiLpi_DD');
    figureTemplate(VBR_sweep, VpiLpi_DD, 'V_R_b_i_a_s (V)', 'V_\piL_\pi (V-cm)', strcat(figPath, 'VpiLpi_DD'));
end

function [VpiLpi, IL, ER, Vpp_y_ee, del_l, VpiLpi_head] = FoM_y (numericalFolder, Wrib_sweep, Hrib_sweep, Hslab_sweep, wl_sweep, VBR, Vpp, Lactive, FSR, N, wl, Hrib, Wrib, Hslab, Wnoffset, Wpslab, Wnslab, Wpbody, Wnbody, NA, ND, NAbody, NDbody, pts, T, gamma_fee, gammat_fee)
    y = linspace(0, Lactive, N); dy = gradient(y);
    k0 = 2 * pi / wl;
    [Neff2, Neff1, Del_alpha2, Del_alpha1, Vpp_y_ee] = SSLV_FCIE (numericalFolder, Wrib_sweep, Hrib_sweep, Hslab_sweep, wl_sweep, Vpp, Lactive, y, wl, Hrib, Wrib, Hslab, Wnoffset, Wpslab, Wnslab, Wpbody, Wnbody, NA, ND, NAbody, NDbody, pts, T, gamma_fee, gammat_fee, VBR);
%     figure; plot(y*1e6, Vpp_y_ee); ylabel('Vpp(y)_e_e [V]'); xlabel('y [um]');
    VpiLpi = Vpp * Lactive * (wl * 100) / 2 / sum((Neff2 - Neff1) .* dy);
    VpiLpi_head = (wl * 100) / 2 / (Neff2(end) - Neff1(end)) * Vpp;
    
    [~, n1] = min(abs(Wrib_sweep - Wrib));
    [~, n2] = min(abs(Hrib_sweep - Hrib));
    [~, n3] = min(abs(Hslab_sweep - Hslab));
    % [~, n4] = min(abs(wl_sweep - wl));
    idxstr = num2str(n1) + "_" + num2str(n2);
    load(pwd + "\\" + numericalFolder + "\neff_channel_" + idxstr + ".mat");
    neff0 = interp1(wl_sweep, conj(neff), wl); % neff0 = conj(neff(n4));
    Ng = interp1(wl_sweep, real(ng), wl); % Ng = real(ng(n4));
    
    idxstr = num2str(n1) + "_" + num2str(n2) + "_" + num2str(n3);
    load(pwd + "\\" + numericalFolder + "\neff_rib_" + idxstr + ".mat");
    neff0_rib = interp1(wl_sweep, conj(neff), wl); % neff0_rib = conj(neff(n4));
    
    del_l = wl^2 / Ng / FSR;        % Extra strip waveguide length for the specific FSR
    del_l = (floor(real(neff0) * del_l / wl) + 0.25) / real(neff0) * wl;    % Corrected extra strip waveguide length for additional 90 degree phase shift
    %% The normalized power transmission for the case of 1:1 power split
    % Tmax = max([0.25 * abs(exp(-1i * k0 * sum(Neff2 .* dy) - sum(100 * Del_alpha2 .* dy)/2 - 1i * k0 * neff0 * del_l) + exp(-1i * k0 * sum(Neff1 .* dy)  - sum(100 * Del_alpha1 .* dy)/2)) ^ 2, 0.25 * abs(exp(-1i * k0 * sum(Neff1 .* dy) - sum(100 * Del_alpha1 .* dy)/2 - 1i * k0 * neff0 * del_l) + exp(-1i * k0 * sum(Neff2 .* dy) - sum(100 * Del_alpha2 .* dy)/2)) ^ 2]);
    % Tmin = min([0.25 * abs(exp(-1i * k0 * sum(Neff2 .* dy) - sum(100 * Del_alpha2 .* dy)/2 - 1i * k0 * neff0 * del_l) + exp(-1i * k0 * sum(Neff1 .* dy)  - sum(100 * Del_alpha1 .* dy)/2)) ^ 2, 0.25 * abs(exp(-1i * k0 * sum(Neff1 .* dy) - sum(100 * Del_alpha1 .* dy)/2 - 1i * k0 * neff0 * del_l) + exp(-1i * k0 * sum(Neff2 .* dy) - sum(100 * Del_alpha2 .* dy)/2)) ^ 2]);
    
    %% Insertion Loss and Extinction Ratio
    % IL = -10 * log10(Tmax);    IL = IL + 20 / log(10) * k0 * abs(imag(neff0_rib)) * Lactive;
    % ER = 10 * log10(Tmax / Tmin);
    alpha0_rib = k0 * abs(imag(neff0_rib));
    alpha2 = alpha0_rib +  100 * Del_alpha2 / 2;
    alpha1 = alpha0_rib +  100 * Del_alpha1 / 2;
    
    % Considering segmented lossy TL, Vpp(y)
    Eout1 = 1/2 * (exp(-1i * k0 * sum(Neff2 .* dy) - sum(alpha2 .* dy) - 1i * k0 * neff0 * del_l) + exp(-1i * k0 * sum(Neff1 .* dy) - sum(alpha1 .* dy)));
    Eout2 = 1/2 * (exp(-1i * k0 * sum(Neff1 .* dy) - sum(alpha1 .* dy) - 1i * k0 * neff0 * del_l) + exp(-1i * k0 * sum(Neff2 .* dy) - sum(alpha2 .* dy)));
    
    % Considering uniform TL, lossless Vpp is constant
    % Eout1 = 1/2 * (exp(-1i * k0 * Neff2(end) * Lactive - alpha2(end) * Lactive - 1i * k0 * neff0 * del_l) + exp(-1i * k0 * Neff1(end) * Lactive - alpha1(end) * Lactive));
    % Eout2 = 1/2 * (exp(-1i * k0 * Neff1(end) * Lactive - alpha1(end) * Lactive - 1i * k0 * neff0 * del_l) + exp(-1i * k0 * Neff2(end) * Lactive - alpha2(end) * Lactive));
    
    Tmax = max([Eout1 * conj(Eout1), Eout2 * conj(Eout2)]);
    Tmin = min([Eout1 * conj(Eout1), Eout2 * conj(Eout2)]);
    
    %% Insertion Loss and Extinction Ratio
    IL = -10 * log10(Tmax);
    ER = 10 * log10(Tmax / Tmin);
end

function  [Neff2, Neff1, Del_alpha2, Del_alpha1, Vpp_y_ee] = SSLV_FCIE (numericalFolder, Wrib_sweep, Hrib_sweep, Hslab_sweep, wl_sweep, Vpp, Lactive, y, wl, Hrib, Wrib, Hslab, Wnoffset, Wpslab, Wnslab, Wpbody, Wnbody, NA, ND, NAbody, NDbody, pts, T, gamma_fee, gammat_fee, VBR)          % Small Signal Lossy Voltage_Free Carrier Induced Effect
%     Vs_ee = Vpp/2 * (1 + gammas_3dBeo * gammat_3dBeo * exp(-2 * gamma_fee * Lactive)) / ((gammas_3dBeo + 1)/2) / (1 + gammat_3dBeo * exp(-2*gamma_fee*Lactive));
    Vpp_y_ee = abs( Vpp * (exp(gamma_fee*y) .* (1 + gammat_fee * exp(-2 * gamma_fee * y))) ./ (exp(gamma_fee*Lactive) * (1 + gammat_fee * exp(-2*gamma_fee*Lactive))) );
%     Vpp_y_eo = abs( Vpp * (exp(i*beta1_3dBeo*y) .* (1 + gammat_3dBeo * exp(-2 * gamma_fee * y))) ./ (exp(i*beta1_3dBeo*Lactive) * (1 + gammat_3dBeo * exp(-2*gamma_3dBeo*Lactive))) );
    Neff2 = []; Neff1 = []; Del_alpha2 = []; Del_alpha1 = [];
    for iVpp_y_ee = 1:length(Vpp_y_ee)
        [neff2, del_alpha2] = neff_alpha_V (numericalFolder, Wrib_sweep, Hrib_sweep, Hslab_sweep, wl_sweep, wl, Hrib, Wrib, Hslab, Wnoffset, Wpslab, Wnslab, Wpbody, Wnbody, NA, ND, NAbody, NDbody, pts, T, VBR + Vpp_y_ee(iVpp_y_ee)/2);
        [neff1, del_alpha1] = neff_alpha_V (numericalFolder, Wrib_sweep, Hrib_sweep, Hslab_sweep, wl_sweep, wl, Hrib, Wrib, Hslab, Wnoffset, Wpslab, Wnslab, Wpbody, Wnbody, NA, ND, NAbody, NDbody, pts, T, VBR - Vpp_y_ee(iVpp_y_ee)/2);
        Neff2 = [Neff2, neff2];
        Neff1 = [Neff1, neff1];
        Del_alpha2 = [Del_alpha2, del_alpha2];
        Del_alpha1 = [Del_alpha1, del_alpha1];
    end
end

function [gamma_3dBeo, gammat_3dBeo] = FindParamAt_f_operation (fee, f, Z0, gamma, Zt)         %%%%% f, f3dB_eo need to * 1e9
    Z0_3dBeo = interp1(f, Z0, fee);
    gamma_3dBeo = interp1(f, gamma, fee);
    gammat_3dBeo = (Zt - Z0_3dBeo) / (Zt + Z0_3dBeo);
end

function [S11dB, S21dB] = FindS (Z0, gamma, Lactive, Zs, Zt)
    gammas = (Z0 - Zs) ./ (Z0 + Zs);
    gammat = (Zt - Z0) ./ (Zt + Z0);
    S11 = (gammas + gammat .* exp(-2*gamma*Lactive)) ./ (1 + gammas .* gammat .* exp(-2*gamma*Lactive));
    S11dB = 20.*log10(abs(S11));
    S21 = (1+gammas) .* (1+gammat) .* exp(-gamma*Lactive) ./ (1 + gammas .* gammat .* exp(-2*gamma*Lactive));
    S21dB = 20.*log10(abs(S21));
end

function [m, phaseplus, phaseminus]= EO_response (numericalFolder, Wrib_sweep, Hrib_sweep, Hslab_sweep, wl_sweep, wl, Hrib, Wrib, Hslab, Wnoffset, Wpslab, Wnslab, Wpbody, Wnbody, NA, ND, NAbody, NDbody, pts, T, f, Z0, gamma, Cj, Rj, Zs, Zt, Lactive, Vs)
    % f need to * 1e9
    c0 = 299792458; % [m/s]
    
    %% load neff from neff_rib_FT
    [~, n1] = min(abs(Wrib_sweep - Wrib));
    [~, n2] = min(abs(Hrib_sweep - Hrib));
    [~, n3] = min(abs(Hslab_sweep - Hslab));
    idxstr = num2str(n1) + "_" + num2str(n2) + "_" + num2str(n3);
    load(pwd + "\\" + numericalFolder + "\neff_rib_" + idxstr + ".mat");
    neff_rib_sweep = interp1(wl_sweep, conj(neff), [wl; wl + 10e-9; wl - 10e-9]);
    
    %% ngo @ Vr = 0V
    % lambda @ wl
    [neff_V, del_alpha_V] = neff_alpha_V (numericalFolder, Wrib_sweep, Hrib_sweep, Hslab_sweep, wl_sweep, wl, Hrib, Wrib, Hslab, Wnoffset, Wpslab, Wnslab, Wpbody, Wnbody, NA, ND, NAbody, NDbody, pts, T, 0);
    k0_wl = 2 * pi / wl;
    neff_V = neff_V + 1i * (abs(imag(neff_rib_sweep(1))) + del_alpha_V * 100 / 2 / k0_wl);
        
    % lambda @ wl + 10nm
    [neff_V_wl2, del_alpha_V_wl2] = neff_alpha_V (numericalFolder, Wrib_sweep, Hrib_sweep, Hslab_sweep, wl_sweep, wl + 10e-9, Hrib, Wrib, Hslab, Wnoffset, Wpslab, Wnslab, Wpbody, Wnbody, NA, ND, NAbody, NDbody, pts, T, 0);
    k0_wl2 = 2 * pi / (wl + 10e-9);
    neff_V_wl2 = neff_V_wl2 + 1i * (abs(imag(neff_rib_sweep(2))) + del_alpha_V_wl2 * 100 / 2 / k0_wl2);
        
    % lambda @ wl - 10nm
    [neff_V_wl1, del_alpha_V_wl1] = neff_alpha_V (numericalFolder, Wrib_sweep, Hrib_sweep, Hslab_sweep, wl_sweep, wl - 10e-9, Hrib, Wrib, Hslab, Wnoffset, Wpslab, Wnslab, Wpbody, Wnbody, NA, ND, NAbody, NDbody, pts, T, 0);
    k0_wl1 = 2 * pi / (wl - 10e-9);
    neff_V_wl1 = neff_V_wl1 + 1i * (abs(imag(neff_rib_sweep(3))) + del_alpha_V_wl1 * 100 / 2 / k0_wl1);
    
    % ngo
    ngo = real(neff_V - wl * (neff_V_wl2 - neff_V_wl1) / (20e-9));

    gammas = (Z0 - Zs) ./ (Z0 + Zs);
    gammat = (Zt - Z0) ./ (Zt + Z0);
    omega = 2 .* pi .* f;
    beta1 = -1i .* (gamma - 1i .* omega .* ngo ./ c0);
    beta2 = -1i .* (gamma + 1i .* omega .* ngo ./ c0);
    Vplus = Vs .* (1 + gammas) ./ 2 ./ (exp(1i*beta1*Lactive) + gammas .* gammat .* exp(-1i*beta2*Lactive)); 
    phaseplus = phaseCoeff(beta1, Lactive, 'plus');
    phaseminus = phaseCoeff(beta2, Lactive, 'minus');
    Vavg = Vplus .* (phaseplus + gammat .* phaseminus);
    Vdep = Vavg ./ (1 + 1i .* omega.*Rj .* Cj);
    m = abs( Vdep ./ Vdep(1));
end

function [phase, phi] = phaseCoeff (beta, Lactive, sign)
    if strcmp(sign, 'plus')
        phi = beta .* Lactive ./ 2;
    else
        phi = -beta .* Lactive ./2;
    end
    phase = exp(1i .* phi) .* sin(phi) ./ (1i .* phi);
end

function figureTemplate(x, y, xlabelStr, ylabelStr, figureName, xlimVector, ylimVector)
    %% plot
    % figure('Units', 'centimeters', 'Position', [20, 10, 8, 6.486]);
    figure('Units', 'centimeters', 'Position', [20, 10, 8, 6.486]);
    set(gca, 'FontSize', 9); 

    %%
    plot(x, y, '-k', 'LineWidth', 1);
    % grid on;
    if nargin == 7
        ylim(ylimVector);
        xlim(xlimVector);
    end
    % set(gca,'YTick', [-70:5:0]);

    %%
    set(gca, 'FontWeight', 'bold', 'LineWidth', 2);

    %%
    ylabel(ylabelStr, 'fontweight', 'bold', 'FontSize', 12);
    xlabel(xlabelStr, 'fontweight', 'bold', 'FontSize', 12);
    % txt = {'applied voltage @', 'both arms ='};
    % text(1300, -50, txt, 'FontWeight', 'bold', 'FontSize', 9);
    % legend({'0V', '1V', '2V'}, 'FontSize', 9, 'Box', 'off');
%     title('V_p_p = 1.56 V');
    savefig(strcat(figureName,'.fig'));
end

%% doping vs resistivity
function NA = Doping_p (Rsp, t)
    rhop = Rsp * t;  % Rsp: [ohm/square], rhop: [ohm*m]
  %% cleanroom.byu.edu/ResistivityCal, Boron I.I. doping
    M = [1E12, 14667.262500697669;...
        2e12, 7334.3074668356185;...
        3e12, 4889.927087022465;...
        4e12, 3667.7102733442443;...
        5e12, 2934.365635920998;...
        6e12, 2445.4601526215956;...
        7e12, 2096.2358218597333;...
        8e12, 1834.3131803545389;...
        9e12, 1630.5922829017052;...
        1E13, 1467.6130226932708;...
        2e13, 734.1605785943417;...
        3e13, 489.6439489075054;...
        4e13, 367.37169384563;...
        5e13, 294.00072283249114;...
        6e13, 245.08199920075117;...
        7e13, 210.13684491389827;...
        8e13, 183.92567879490377;...
        9e13, 163.53749497737368;...
        1E14, 147.2256168021463;...
        2e14, 73.79819816655328;...
        3e14, 49.30538454654703;...
        4e14, 37.051678632073724;...
        5e14, 29.6954663078232;...
        6e14, 24.788841344326187;...
        7e14, 21.282429079816335;...
        8e14, 18.651415388971305;...
        9e14, 16.604170143963735;...
        1e15, 14.965676972314505;...
        2e15, 7.579908648305307;...
        3e15, 5.109080787309241;...
        4e15, 3.8698450424845046;...
        5e15, 3.1242150676530103;...
        6e15, 2.6258280446610405;...
        7e15, 2.268957205168585;...
        8e15, 2.0006719602343748;...
        9e15, 1.7915300674070833;...
        1E16, 1.6238443702134566;...
        2e16, 0.8616982987851544;...
        3e16, 0.6007793658993279;...
        4e16, 0.4668833077437573;...
        5e16, 0.3848097488327641;...
        6e16, 0.32916413932536687;...
        7e16, 0.28887714529663105;...
        8e16, 0.25832187283212754;...
        9e16, 0.23432669984878876;...
        1E17, 0.21496536080345086;...
        2e17, 0.12511746716382996;...
        3e17, 0.09321100328175008;...
        4e17, 0.07634129495480432;...
        5e17, 0.06568624199523963;...
        6e17, 0.058237674979408;...
        7e17, 0.05267784309720679;...
        8e17, 0.04833354819073814;...
        9e17, 0.044822807002399274;...
        1E18, 0.04191163444675014;...
        2e18, 0.026966103247715024;...
        3e18, 0.02071543061160277;...
        4e18, 0.01708643063417176;...
        5e18, 0.014656473723778948;...
        6e18, 0.012892019382870181;...
        7e18, 0.01154155651659908;...
        8e18, 0.010468880767556137;...
        9e18, 0.009592965508561903;...
        1E19, 0.00886221011340648;...
        2e19, 0.005131728638834896;...
        3e19, 0.0036579869149012435;...
        4e19, 0.0028561262015310857;...
        5e19, 0.002349211020946666;...
        6e19, 0.0019989859115629813;...
        7e19, 0.0017422817628892251;...
        8e19, 0.0015459975398086781;...
        9e19, 0.00139106420123108;...
        1e20, 0.0012657019138033899;...
        2e20, 0.0006897187930032605;...
        3e20, 0.0004998786019967727;...
        4e20, 0.0004094563399566657;...
        5e20, 0.0003577783126309449;...
        6e20, 0.00032423639614114494;...
        7e20, 0.00030011836259918087;...
        8e20, 0.00028128252654560214;...
        9e20, 0.00026562246738990046;...
        1e21, 0.00025201950291479263];
    
    %% Boron I.I.
    doping = 1e6 * M(:, 1);  % transfer from [cm^-3] to [m^-3]
    r = 0.01 * M(:, 2);      % transfer from [ohm-cm] to [ohm-m]
    
    %% interpl
    NA = 10 ^ interp1(r, log10(doping), rhop);
end

function ND = Doping_n (Rsn, t)
    rhon = Rsn * t; % Rsn: [ohm/square], rhon: [ohm-m]
    %% cleanroom.byu.edu/ResistivityCal, Phosphorus I.I. doping
    M = [1e12, 4415.312387249216;...
        2e12, 2208.0516252889915;...
        3e12, 1472.260794813711;...
        4e12, 1104.3494534905074;...
        5e12, 883.593966403182;...
        6e12, 736.4182459153325;...
        7e12, 631.2890861537179;...
        8e12, 552.4396063742955;...
        9e12, 491.11028238255386;...
        1e13, 442.0453159585842;...
        2e13, 221.2258953366559;...
        3e13, 147.6002720150266;...
        4e13, 110.77927061797217;...
        5e13, 88.68220465551408;...
        6e13, 73.94805219339818;...
        7e13, 63.42178267013413;...
        8e13, 55.5257379731432;...
        9e13, 49.38336630535094;...
        1e14, 44.4686935514395;...
        2e14, 22.338735736616144;...
        3e14, 14.952225669892737;...
        4e14, 11.2547527654003;...
        5e14, 9.03396836755867;...
        6e14, 7.552014950229166;...
        7e14, 6.492509980307877;...
        8e14, 5.697188698869662;...
        9e14, 5.078087610023568;...
        1e15, 4.582406466925789;...
        2e15, 2.3446428190337527;...
        3e15, 1.5936188312472996;...
        4e15, 1.2159178983143852;...
        5e15, 0.9881007516938989;...
        6e15, 0.8354771661910652;...
        7e15, 0.7259555395677811;...
        8e15, 0.643452105317738;...
        9e15, 0.5790114696983483;...
        1e16, 0.527248940778915;...
        2e16, 0.29052217421980503;...
        3e16, 0.20890178710676735;...
        4e16, 0.16691593198161894;...
        5e16, 0.14107609616679467;...
        6e16, 0.12344257457228096;...
        7e16, 0.11056980467025358;...
        8e16, 0.10071498770296652;...
        9e16, 0.09289934113086042;...
        1e17, 0.08652951863165105;...
        2e17, 0.05571655256990463;...
        3e17, 0.043882899033872075;...
        4e17, 0.037276332798897575;...
        5e17, 0.03292880659958998;...
        6e17, 0.02978892208221377;...
        7e17, 0.027381574619978873;...
        8e17, 0.025457601255549075;...
        9e17, 0.02387237860989364;...
        1e18, 0.022535527511173582;...
        2e18, 0.015296376795037384;...
        3e18, 0.012046447049756204;...
        4e18, 0.010088747307958466;...
        5e18, 0.008746434208670373;...
        6e18, 0.007755106254631488;...
        7e18, 0.0069865311094907704;...
        8e18, 0.006369761891436145;...
        9e18, 0.005861872543276224;...
        1e19, 0.005435145683486666;...
        2e19, 0.0032109478254829377;...
        3e19, 0.0023085709125624998;...
        4e19, 0.0018107291820831128;...
        5e19, 0.0014930022758197375;...
        6e19, 0.001271837287890109;...
        7e19, 0.0011086827741232424;...
        8e19, 0.0009831936158292054;...
        9e19, 0.0008835852987861998;...
        1e20, 0.000802546357126152;...
        2e20, 0.00042070536404033483;...
        3e20, 0.0002859354020328652;...
        4e20, 0.0002167940227303361;...
        5e20, 0.00017466969978011874;...
        6e20, 0.00014629489974523987;...
        7e20, 0.00012587374537441188;...
        8e20, 0.00011046899716362771;...
        9e20, 0.00009843223638040267;...
        1e21, 0.000088766503533662];
    %%
    doping = 1e6 * M(:, 1);  % transfer from [cm^-3] to [m^-3]
    r = 0.01 * M(:, 2);  % transfer from [ohm-cm] to [ohm-m]

    %%
    ND = 10 ^ interp1(r, log10(doping), rhon);
end