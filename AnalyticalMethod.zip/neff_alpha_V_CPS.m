%% Function Name: neff_alpha_V_CPS
% Author: Sheldon Chung, National Taiwan University, EE2-354, e-mail: r04941128@ntu.edu.tw; b00901194@ntu.edu.tw
%
% No one is allowed using this .m file unless author's permission.
%
% Assumptions: Analytical Carrier Density Profile of PN depletion region
%
% Inputs:
%   List of input arguments
%
% Outputs:
%   neff, del_alpha due to free carrier plasma dispersion effect
%
% $Date: Dec 27, 2018
% Copyright Sheldon Chung
% ________________________________________

function [neff, del_alpha, ne_int, nh_int, alphah_int, denominator_int] = neff_alpha_V_CPS (numericalFolder, Wrib_sweep, Hrib_sweep, Hslab_sweep, wl_sweep, wl, Hrib, Wrib, Hslab, Wnoffset, Wpslab, Wnslab, Wpbody, Wnbody, NA, ND, NAbody, NDbody, pts, T, VR)
    %% assign the LocalParams
    % numericalFolder = LP.numericalFolder;
    % Wrib_sweep = LP.Wrib_sweep;
    % Hrib_sweep = LP.Hrib_sweep;
    % Hslab_sweep = LP.Hslab_sweep;
    % wl_sweep = LP.wl_sweep;
    % wl = LP.wl;
    % Hrib = LP.Hrib;
    % Wrib = LP.Wrib;
    % Hslab = LP.Hslab;
    % Wnoffset = LP.Wnoffset;
    % Wpslab = LP.Wpslab;
    % Wnslab = LP.Wnslab;
    % Wpbody = LP.Wpbody;
    % Wnbody = LP.Wnbody;
    % NA = LP.NA;
    % ND = LP.ND;
    % NAbody = LP.NAbody;
    % NDbody = LP.NDbody;
    % pts = LP.pts;
    % T = LP.T;
    % VR = LP.VR          % VR = VRB + .5 or .25*Vpp

    %% PN analytical 1D concentration
    [n, p, xdoping] = AnalyticCarrierDensityProfile (T, VR, pts, NAbody, NA, ND, NDbody, Wrib, Wnoffset, Wpslab, Wnslab, Wpbody, Wnbody);
    % plot(xdoping, n, '-b', xdoping, p, '-r');
    [~, n1] = min(abs(Wrib_sweep - Wrib));
    [~, n2] = min(abs(Hrib_sweep - Hrib));
    [~, n3] = min(abs(Hslab_sweep - Hslab));
    [~, n4] = min(abs(wl_sweep - wl));
    idxstr = num2str(n1) + "_" + num2str(n2) + "_" + num2str(n3) + "_" + num2str(n4);
    load(pwd + "\\" + numericalFolder + "\Ex_rib_" + idxstr + ".mat");
    idxstr = num2str(n1) + "_" + num2str(n2) + "_" + num2str(n3);
    load(pwd + "\\" + numericalFolder + "\neff_rib_" + idxstr + ".mat");
    neff0_rib = interp1(wl_sweep, conj(neff), wl);
    
    x = x_E.'; I = I_E.'; z = z_E - Hrib/2;
    neff0 = real(neff0_rib);
%     figure; imagesc(x, z, I(end:-1:1, :));
%     colormap jet;
    dxEx = gradient(x);
    dzEx = gradient(z);
    if sum(isnan(VR)) > 0 || sum(isnan(n)) > 0 || sum(isnan(xdoping)) > 0
        neff = NaN;
        del_alpha = NaN;
        return;
    end
    
    n_wg = interp1(xdoping, n, x);
    n_wg_notnan = n_wg(~isnan(n_wg));
    n_wg(isnan(n_wg)) = n_wg_notnan(end);
    
    p_wg = interp1(xdoping, p, x);
    p_wg_notnan = p_wg(~isnan(p_wg));
    p_wg(isnan(p_wg)) = p_wg_notnan(end);
    
    p_wg = repmat(p_wg, length(z), 1);
    n_wg = repmat(n_wg, length(z), 1);
    
    [x, z] = meshgrid(x, z);
    n_wg(abs(z) >= Hrib/2) = 0;
    n_wg(abs(x) >= Wrib/2 & z >= (Hslab - Hrib/2)) = 0;
    p_wg(abs(z) >= Hrib/2) = 0;
    p_wg(abs(x) >= Wrib/2 & z >= (Hslab - Hrib/2)) = 0;
    I(abs(z) >= Hrib/2) = 0;
    I(abs(x) >= Wrib/2 & z >= (Hslab - Hrib/2)) = 0;
    Idxdz = I .* (dzEx * dxEx);     % I is the intensity of Electric filed = |Ex|^2 + |Ey|^2 + |Ez|^2
    denominator_int = sum(sum(Idxdz));    
    ne_int = sum(sum((n_wg*1e-6) .* Idxdz));
    nh_int = sum(sum((p_wg*1e-6).^0.8 .* Idxdz));
    alphah_int = sum(sum((p_wg*1e-6) .* Idxdz));
    del_ne = -3.64e-10*wl^2 * ne_int / denominator_int;   % [1]
    del_nh = -3.51e-6*wl^2 * nh_int / denominator_int;   % [1]
    del_alpha_e = 3.52e-6*wl^2 * ne_int / denominator_int;        % [cm^-1]
    del_alpha_h = 2.4e-6*wl^2 * alphah_int / denominator_int;     % [cm^-1]
    
    %% necessary calculation
    del_neff = del_ne + del_nh; % [1]
    neff = neff0 + del_neff;  % [1]
    del_alpha = del_alpha_e + del_alpha_h;      % [cm^-1] 'power loss', / 2 is needed for electrical field exponential term.
end

%% AnalyticalCarrierDensity
function [n, p, xdoping] = AnalyticCarrierDensityProfile (T, VR, pts, NAbody, NA, ND, NDbody, Wrib, Wnoffset, Wpslab, Wnslab, Wpbody, Wnbody)
    %% Basic Constants
    ep0 = 8.854187817e-12;  % [F/m]
    erSi = 11.9; % [1]
    e = 1.602176487e-19; % element charge [C]
    h = 6.62606896e-34; % Plank's constant [J-s]
    h_eV = h / e; % Plank's constant [eV-s]
    kB = 1.3806504e-23; % [J/K]
    m_0 = 9.11e-31; % electron mass [kg]
    Eg = 1.1242; % band gap for Si [eV]
    VT = kB * T / e; % thermal voltage [eV]

    %% Derived parameters
%     ds_pbody = Wpslab + Wrib/2 + Wnoffset;     % distance between the p-body boundary and the pn junction centre
%     ds_nbody = Wnslab + Wrib/2 - Wnoffset;     % distance between the n-body boundary and the pn junction centre
    m_n = 1.08*m_0; % Density-of-states effective mass for electrons
    m_p = 1.15*m_0; % Density-of-states effective mass for holes
    Nc = 2*(2*pi*m_n*(kB/e)*T/h_eV^2)^(3/2)/(e)^(3/2); % Effective Density of states for Conduction Band
    Nv = 2*(2*pi*m_p*(kB/e)*T/h_eV^2)^(3/2)/(e)^(3/2); % Effective Density of states for Valence Band
    ni = sqrt(Nc*Nv).*exp(-Eg/(2*(kB/e)*T)); % intrinsict charge carriers in m^-3
    Vbi = VT*log(NA*ND/ni^2); % built-in or diffusion potential
    Wd = sqrt(2*ep0*erSi*(NA+ND) / (e*NA*ND) .*(Vbi + VR - 2*VT)); % depletion width
    Wdp = Wd./(1+NA/ND); Wdn = Wd./(1+ND/NA);
    xp = -Wdp + Wnoffset;       % location of the depletion p boundary
    xn = Wdn + Wnoffset;        % location of the depletion n boundary
    dx = Wrib ./ (pts-1);         % segmented rib in x direction
%     x_pbody = -ds_pbody + Wnoffset; % location of the pbody inner boundary
%     x_nbody = ds_nbody + Wnoffset;  % location of the nbody inner boundary
    x_pbody = -Wrib/2 - Wpslab;
    x_nbody = Wrib/2 + Wnslab;
    x_min = x_pbody - Wpbody;     % location of the pbody outer boundary
    x_max = x_nbody + Wnbody;         % location of the nbody outer boundary
    
    %% 
    x_NAbody = x_min:dx:(x_pbody-dx);  % sampling location in x direction @ NAbody doped region
    x_NA = x_pbody:dx:(xp-dx);          % sampling location in x direction @ NA doped region
    x_dep = xp:dx:xn;                     % sampling location in x direction @ depletion region
    x_ND = (xn+dx):dx:x_nbody;          % sampling location in x direction @ ND doped region
    x_NDbody = (x_nbody+dx):dx:x_max;      % sampling location in x direction @ NDbody doped region
    xdoping = [x_NAbody, x_NA, x_dep, x_ND, x_NDbody];
    n0_NA = ni^2/NA; p0_ND = ni^2/ND;
    n0_NAbody = ni^2 / NAbody; p0_NDbody = ni^2 / NDbody;
    
    %%
    % Long-base assumption
    % Lp=sqrt(Dp*tau_p);
    % Ln=sqrt(Dn*tau_n);
    % del_n_NA=n0_NA*(exp(q*V/(kB*T))-1)* exp(-abs(x_NA-xp)/Ln); % minority electron density in p(NA) region
    % del_p_ND=p0_ND*(exp(q*V/(kB*T))-1)* exp(-abs(x_ND-xn)/Lp); % minority hole density in n(ND) region
    
    % Short-base assumption
    dn_NA = n0_NA*(exp(e*-VR/(kB*T))-1)*(1-abs((x_NA-xp)/(xp-x_pbody))); % minority electron density in p(NA) region
    dp_ND = p0_ND*(exp(e*-VR/(kB*T))-1)*(1-abs((x_ND-xn)/(x_nbody-xn))); % minority hole density in n(ND) region
    
    %% All the analytical concentration expression
    n_NA = n0_NA + dn_NA; p_ND = p0_ND + dp_ND;             % minority carrier density
    p_dep = zeros(1, length(x_dep)); n_dep = zeros(1, length(x_dep));        % concentration in depletion region   
    p_NA = ones(1, length(x_NA))*NA; % majority holes in p(NA) region
    n_ND = ones(1, length(x_ND))*ND; % majority electrons in n(ND) region
    n_NAbody = ones(1, length(x_NAbody))*n0_NAbody;% assumption of uniform electrons in p++
    p_NDbody = ones(1, length(x_NDbody))*p0_NDbody;% assumption of uniform holes in n++
    p_NAbody = ones(1, length(x_NAbody))*NAbody; % majority holes in p++ region
    n_NDbody = ones(1, length(x_NDbody))*NDbody; % majority electrons in n++ region
    
    %% peak point: (x1, y2); lowest point: (x2, y1) for p-side depletion distribution
%     y1 = log10(p_ND(1));
%     y2 = log10(p_NA(end)); 
%     x1 = xp; 
%     x2 = xn;
%     y = @(x, sigmas) y1 + (y2 - y1) .* exp(-(x - x1) .^ 2 ./ 2 ./ sigmas .^ 2);
%     sigma0 = (x1 + x2) / 2;
%     sigma_rt = fzero(@(sigma0) y(x2, sigma0) - y1, sigma0);
%     p_dep = 10 .^ y(x_dep, sigma_rt);
%     y = @(x) y1 + - (y2 - y1) ./ (x2 - x1) .* (x - x1);
%     p_dep = 10 .^ y(x_dep);
    
    %% peak point: (x1, x2); lowest point: (x2, y1) for n-side depletion distribution
%     y1 = log10(n_NA(end));
%     y2 = log10(n_ND(1)); 
%     x1 = xn; 
%     x2 = xp;
%     y = @(x, sigmas) y1 + (y2 - y1) .* exp(-(x - x1) .^ 2 ./ 2 ./ sigmas .^ 2);
%     sigma0 = (x1 + x2) / 2;
%     sigma_rt = fzero(@(sigma0) y(x2, sigma0) - y1, sigma0);
%     n_dep = 10 .^ y(x_dep, sigma_rt);
%     y = @(x) y1 + - (y2 - y1) ./ (x2 - x1) .* (x - x1);
%     n_dep = 10 .^ y(x_dep);

    p = [p_NAbody, p_NA, p_dep, p_ND, p_NDbody]; n = [n_NAbody, n_NA, n_dep, n_ND, n_NDbody];
end