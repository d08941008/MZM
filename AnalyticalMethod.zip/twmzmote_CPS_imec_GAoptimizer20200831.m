% Author: Sheldon Chung, EE2-354, d089841008@ntu.edu.tw/r04941128@ntu.edu.tw/b00901194@ntu.edu.tw/b00901194@ntu
%
% The script is to optimize the performance of the coplanar-waveguide differential-drive traveling-wave modulator
%
% Copyright SheldonChung

function  twmzmote_CPS_imec_GAoptimizer20200831 (folderName, ER_min, BW_min, optNum, Vpp)
    % usage: twmzmote_imec_GAoptimizer0822 ('GAoptimization_results_20200822', 50, 1, 2.5);
    
    if ~exist(folderName, 'dir') ~= 0
        mkdir(folderName);
    end
    
    %% Global Params
    ep0 = 8.854187817e-12;  % [F/m]
    erSi = 11.9; % [1]
    erSiO2 = 3.9; % [1]
    mu0 = 4*pi*1e-7; % [H/m]
    c0 = 299792458; % [m/s]
    e = 1.602176487e-19; % element charge [C]
    h = 6.62606896e-34; % Plank's constant [J-s]
    h_eV = h / e; % Plank's constant [eV-s]
    kB = 1.3806504e-23; % [J/K]
    m_0 = 9.11e-31; % electron mass [kg]
    Eg = 1.1242; % band gap for Si [eV]
    
    %% Controlled Params
    % ER_min = 5.5; % minimum Dynamic Extinction Ratio due to peak to peak voltage

    %% Params
    r_fee = 1;
    VBR = 2;     % reverse bias, [V]
    Lactive = 1.5e-3;           % length of the TWE (traveling wave electrode), [m]
    delz = 1e-6;
    wl = 1.31e-6;   % optical wavelength, [m]
    Wrib = 0.38e-6;         % rib waveguide width, [m]
    FSR = 20e-9;    % free space range [m]

    T = 300;    % temperature, [K]
    Zs = 50; % source impedance, [ohm]
    Zt = 36 * 30 / 35.6; % terminal impedance, [ohm]
    sigma_elec = 5.96e7;    % conductivity of metal traces, [S/m] or [1/(ohm*m)]
    sigma_SOI = 1/10e-2;     % conductivity of SOI unprocessed silicon [S/m]
    sigma_sub = 1/16e-2;   % conductivity of substrate, [S/m]
    t = 0.5e-6;       % thickness of metal traces, [m]
    % a = 5.5e-6;       % width of the center metal trace (source metal trace), [m]
    Wpslab = 0.3e-6;       % width of the normally p-doped slab region, [m]
    Wnslab = 0.3e-6;       % width of the normally n-doped slab region, [m]
    Wnoffset = 0e-9;          % distance between pn junction and rib center, [m]
    Wpbody = 0.975e-6;       % width of the intermediate p-doped slab region, [m]
    Wnbody = 0.975e-6;    % width of the intermediate n-doped slab region, [m]
    Wcontact = 1.8e-6;        % width of the highly p/n-doped rib contact region, [m]
    Wpplus_inner = 0.235e-6;      % width of the highly p-doped rib inner region, [m]
    Wpplus_outer = 0.2e-6;      % width of the highly p-doped rib outer region, [m]
    Wpplus = Wpplus_inner + Wcontact + Wpplus_outer;
    Wnplus_inner = 0.235e-6;      % width of the highly n-doped rib inner region, [m]
    Wnplus_outer = 0.2e-6;      % width of the highly n-doped rib outer region, [m]
    Wnplus = Wnplus_inner + Wcontact + Wnplus_outer;
    % b = round((a + 2 * (Wrib + Wpslab + Wnslab + Wpbody + Wnbody + Wpplus_inner + Wnplus_inner))/1e-9)*1e-9;      % width of inner sidewalls of the ground metal traces, [m]
    a = round(2 * (Wrib + Wpslab + Wnslab + Wpbody + Wnbody + Wpplus_inner + Wnplus_inner + 0.9e-6)/1e-9) * 1e-9;
    % Wgnd = 50e-6;
    Wmt = 30e-6;
    % c = b + 2 * Wgnd;     % width of outer sidewalls of the ground metal traces, [m]
    b = round((a + 2 * Wmt) / 1e-9) * 1e-9;     % width of outer sidewalls of the ground metal traces, [m]
    t_MH = 1e-6;        % distance between metral trace lower y and rib waveguide higher y, [m]
    t_BOX = 2e-6;       % depth of burried oxide, [m]
    t_sub = 725e-6;     % depth of the substrate, [m]
    Hrib = 0.22e-6;        % rig waveguide height, [m]
    Hslab = 0.06e-6;   % height of the slab, [m]

    %% Doping concentration
    NA = 5e23;      % per m^3
    ND = 5e23;      % per m^3
    NAbody = 3e25;  % per m^3
    NDbody = 3e25;  % per m^3
    NAplus = 3e26;  % per m^3
    NDplus = 3e26;  % per m^3

    pts = 380;   % # of points in waveguide along x direction
    N = 1500;      % # of points in active phase shifter diode region along propagation direction
    Vs = 1;         % RF driving signal
    f = 0.1:0.1:100; % GHz

    %% sweep data for loading Ex
    Wrib_sweep = Wrib - 0.025e-6: 0.005e-6: Wrib + 0.025e-6;
    Hrib_sweep = Hrib - 0.005e-6: 0.005e-6: Hrib + 0.005e-6;
    Hslab_sweep = Hslab - 0.015e-6: 0.005e-6: Hslab + 0.015e-6;
    wl_sweep = wl - 40e-9: 10e-9: wl + 40e-9;
    if wl == 1.31e-6
        numericalFolder = 'numericalData_Oband';
    end
    if wl == 1.55e-6
        numericalFolder = 'numericalData_Cband';
    end

    try
        tic
        [f3dB_eo, gamma_3dBeo, gammat_3dBeo] = RF_analysis_all (numericalFolder, Wrib_sweep, Hrib_sweep, Hslab_sweep, wl_sweep, wl, r_fee, f, VBR, T, sigma_elec, sigma_SOI, sigma_sub, t, a, b, t_MH, Hslab, t_BOX, t_sub, NA, ND, NAbody, NDbody, NAplus, NDplus, Wpslab, Wnslab, Wpbody, Wnbody, Wcontact, Wpplus_inner, Wnplus_inner, Wpplus_outer, Wnplus_outer, Hrib, Wrib, Wnoffset, Lactive, Zs, Zt, Vs, pts);
        [VpiLpi, IL, ER, Vpp_y_ee, del_l] = FoM_y (numericalFolder, Wrib_sweep, Hrib_sweep, Hslab_sweep, wl_sweep, VBR, 2.5, Lactive, FSR, N, wl, Hrib, Wrib, Hslab, Wnoffset, Wpslab, Wnslab, Wpbody, Wnbody, NA, ND, NAbody, NDbody, pts, T, gamma_3dBeo, gammat_3dBeo);
        fprintf('**********\ntest_case:\nf3dB_eo = %f [GHz]\nVpiLpi = %f [V-cm]\nIL = %f [dB]\nER = %f [dB]\ndel_l = %f [um]\n', f3dB_eo, VpiLpi, IL, ER, del_l*1e6);
        toc
        fprintf('**********\n');

        %% Set Gene max and min values
        i_discrete = 4;
        param = importdata(strcat('TWMZMOTE_ParamRange_theOptimized', num2str(optNum), '.txt'));
        X = param.data.';
        
        %%  Call GA function
        NP = 200;                   % NP must be even number
        
        % sortOption = 'descend';     % to maximize the fom
        sortOption = 'ascend';      % to minimize the fom
    
        tic
        [Sortf, SortOptM, gen] = GA (numericalFolder, folderName, sortOption, ER_min,  BW_min, X, NP, i_discrete, optNum, Wrib_sweep, Hrib_sweep, Hslab_sweep, wl_sweep, Vpp);
        
        r_fee = Sortf(1, 1);
        VBR = Sortf(1, 2);
        Lactive = Sortf(1, 12);
        Zt = Sortf(1, 3);
        Wmt = Sortf(1, 4);
        Wpslab = Sortf(1, 5);
        Wnslab = Sortf(1, 6);
        Wnoffset = Sortf(1, 7);
        Wpbody = Sortf(1, 8);
        Wnbody = Sortf(1, 9);
        Wpplus_inner = Sortf(1, 10);
        Wnplus_inner = Sortf(1, 11);
        a = round(2*(Wrib + Wpslab + Wnslab + Wpbody + Wnbody + Wpplus_inner + Wnplus_inner + 0.9e-6)/1e-9) * 1e-9;
        b = round((a + 2 * Wmt)/1e-9) * 1e-9;
        
        %% comsol and print the final result of GA
        txtfilePath = strcat(pwd, '\\', folderName, '\TWMZMOTE_theOptimized', num2str(optNum), '_diary.txt');
        if ~exist(txtfilePath, 'file') == 0
            delete(txtfilePath);
        end
        diary(txtfilePath);  clear txtfilePath;
        fprintf('\n**************\nNP = %.0f, Gen = %.0f\n', NP, gen);
        toc
        fprintf('**************************************\n**************************************\nthe final opt matrix of f:\n');
        fprintf('            r_fee = %f [1]\n', r_fee);
        fprintf('            VBR = %f [V]\n', VBR);
        fprintf('            Lactive = %f [um]\n', Lactive);
        fprintf('            Zt = %f [ohm]\n', Zt);
        fprintf('            Wmt = %f [um]\n', Wmt * 1e6);
        fprintf('            Wpslab = %f [um]\n', Wpslab * 1e6);
        fprintf('            Wnslab = %f [um]\n', Wnslab * 1e6);
        fprintf('            Wnoffset = %f [um]\n', Wnoffset * 1e6);
        fprintf('            Wpbody = %f [um]\n', Wpbody * 1e6);        
        fprintf('            Wnbody = %f [um]\n', Wnbody * 1e6);
        fprintf('            Wpplus_inner = %f [um]\n', Wpplus_inner * 1e6);
        fprintf('            Wnplus_inner = %f [um]\n', Wnplus_inner * 1e6);
        fprintf('            a = %f [um]\n', a * 1e6);
        fprintf('            b = %f [um]\n', b * 1e6);
        fprintf('            the best FoM = %f \n', SortOptM(1, 1));
        fprintf('            the operating frequency of the best FoM = %f [GHz]\n', SortOptM(1, 2));
        fprintf('            the ER of the bset FoM = %f [dB]\n', SortOptM(1, 3));
        fprintf('            the IL of the bset FoM = %f [dB]\n', SortOptM(1, 4));
        fprintf('            the VpiLpi of the best FoM = %f [V-cm]\n', SortOptM(1, 5));
        diary off; clear txtfilePath;
        
        save(strcat(pwd, '\\', folderName, '\TWMZMOTE_theBestGenes_theOptimized', num2str(optNum)), 'Lactive', 'Zt', 'a', 'Wpslab', 'Wnslab', 'Wpbody', 'Wnbody', 'Wnoffset', 'r_fee', 'VBR', 'Vpp', 'Zt', 'b', 'Wpplus_inner', 'Wnplus_inner');
        
        %% plot and save
        % figPath = strcat(pwd, '\\', folderName, '\theOptimized', num2str(optNum), '_');
        % [fee, gamma_fee, gammat_fee, f3dB_eo] = RF_analysis_all_figure (numericalFolder, figPath, Wrib_sweep, Hrib_sweep, Hslab_sweep, wl_sweep, wl, r_fee, f, VBR, T, sigma_elec, sigma_SOI, sigma_sub, t, a, b, c, t_MH, Hslab, t_BOX, t_sub, NA, ND, NAbody, NDbody, NAplus, NDplus, Wpslab, Wnslab, Wpbody, Wnbody, Wcontact, Wpplus_inner, Wnplus_inner, Wpplus_outer, Wnplus_outer, Hrib, Wrib, Wnoffset, Lactive, Zs, Zt, Vs, pts);
        % [VpiLpi, IL, ER, Vpp_y_ee, del_l] = FoM_y (numericalFolder, Wrib_sweep, Hrib_sweep, Hslab_sweep, wl_sweep, VBR, Vpp, Lactive, FSR, N, wl, Hrib, Wrib, Hslab, Wnoffset, Wpslab, Wnslab, Wpbody, Wnbody, NA, ND, NAbody, NDbody, pts, T, gamma_fee, gammat_fee);
        
        % dos('powershell.exe set-executionpolicy remotesigned;powershell.exe -file "C:\RaynChung\email_notificator\mail.ps1"');
    catch e
        txtfilePath = strcat(pwd, '\\', folderName, '\ErrorMessage.txt');
        diary(txtfilePath);
        fprintf(1,'\nThe identifier was:\n%s', e.identifier);
        fprintf(1,'There was an error! The message was:\n%s', e.message);
        diary off; clear txtfilePath;
        
        % dos('powershell.exe set-executionpolicy remotesigned;powershell.exe -file "C:\RaynChung\email_notificator\mail_error.ps1"');
    end
end

%% Sub function
function [Sortf, SortOptM, gen] = GA (numericalFolder, folderName, sortOption, ER_min,  BW_min, X, NP, i_discrete, optNum, Wrib_sweep, Hrib_sweep, Hslab_sweep, wl_sweep, Vpp)
    % sortOption = 'descend';       % or 'ascend';
    
    %     X(1,:) is the max value of genes, X(2,:) is the min value of genes
    
    %% GA parameter
    D = size(X,2); % number of genes to form 1 Chromosome (i.e. # of inputs, = size(X,2))
    Pc = 0.8; % crossover rate
    Pm = 0.1; % mutation rate
    dX = repmat(X(1,:) - X(2,:), NP, 1);
    rd = logical(zeros(NP, D)); rd(:, i_discrete:end) = 1; % considering position of gene >= i_discrete, in param.txt, need to be discrete stpes with 10nm. These genes are geometry structure in param.txt.
    idx = logical(rd);
    f = rand(NP,D).* dX + X(2,:); % get father input matrix randomly
    f(idx) = round(f(idx) / 5e-9) * 5e-9;    % column positions >= i_discrete, steps with 5nm
    
    %% get the study solutions and return the objective functions( ConcArea and Chi here) through the matlab function form
    parfor np = 1:NP
        A = Fitness (numericalFolder, ER_min, BW_min, X, f(np, :), i_discrete, Wrib_sweep, Hrib_sweep, Hslab_sweep, wl_sweep, Vpp);
        OptM(np, :) = A(1:5);
        f(np, :) = A(6:end);      % return the new f(np, :) until if fits the constraints in the function 'Fitness'
    end
    
    %% Sort the f with descending fitness function
    [~, index] = sort(OptM(:, 1), sortOption); % to maximize/minimize the objective function, the 1st of Chi must be the biggest
    SortOptM = OptM(index, :);
    Sortf = f(index, :);
    
    %% GA loop
    gen = 0; iEmper = 0; Emper0 = Sortf(1, :);
    while iEmper <= 50        % loop until 50 times of the same best fom
        gen = gen + 1;
        Emper = Sortf(1, :);
        if Emper == Emper0
        % if floor(Emper*1e8) == floor(Emper0*1e8)
            iEmper = iEmper + 1;
        else
            iEmper = 0;
            Emper0 = Emper;
        end
        NPoint = round(D * Pc); % points number of inputs for crossover
        for i = 1:NP/2
           PoPoint(i, :) =  randperm(D, NPoint);
        end
        nf = Sortf; % initialize nf with the same size of Sortf
        
        %% Crossover        
        % crossover and mutation to get the son input matrix nf
        % crossover and return to nf
        for i = 1:NP/2
            nf(2*i-1, :) = Emper;
            nf(2*i, :) = Sortf(2*i, :);
            for k = 1:NPoint
                nf(2*i-1, PoPoint(i, k)) = nf(2*i,PoPoint(i, k));
                nf(2*i, PoPoint(i, k)) = Emper(PoPoint(i, k));
            end
        end
        
        %% Mutation
        % mutatation if rand()< the mutation rate Pm
        for m = 1:NP
            for n = 1:D
                r = rand(1,1);
                if(r < Pm)
                    nf(m, n) = rand(1,1) * (X(1,n) - X(2,n)) + X(2,n);
                    if n >= i_discrete
                        nf(m, n) = round(nf(m, n) / 5e-9) * 5e-9;    % column positions >= i_discrete, steps with 5nm
                    end
                end
            end
        end         
        
        %% Calculation of fitness function of nf
        % input the son input matrix nf and return the objective function
        % fprintf('\nfunc_GA::gen(%.0f)::NOptM = Fitness(nf)\n',gen);
        parfor np = 1:NP 
                A = Fitness (numericalFolder, ER_min, BW_min, X, nf(np, :), i_discrete, Wrib_sweep, Hrib_sweep, Hslab_sweep, wl_sweep, Vpp);
                NOptM(np, :) = A(1: 5);
                nf(np, :) = A(6: end);       %  return the new f(np, :) until it ftis the constraints in the function 'Fitness'
        end
        
        %% sort nf
        % sort the fitness function matrix and f in terms of FoM
        [~,index] = sort(NOptM(:, 1), sortOption); % to maximize/minimize the objective function, the 1st must be the biggest
        NSortOptM = NOptM(index, :);
        NSortf = nf(index, :);
        
        %% merge and sort
        % merge the son generation and father generation
        f1 = [Sortf; NSortf];
        OptM1 = [SortOptM; NSortOptM]; 
        % sort the merged generation
        [~,index] = sort(OptM1(:, 1), sortOption); % to maximize/minimize the objective function, the 1st must be the biggest
        SortOptM1 = OptM1(index, :);
        Sortf1 = f1(index, :);
        
        %% assign the new sortf for the next generation
        % the first NP group becomes the new matrix
        SortOptM = SortOptM1(1:NP, :);
        Sortf = Sortf1(1:NP, :);
        
        trace(gen) = SortOptM(1, 1); % return the best FoM of the group whitin this generation
        
        %% print the best params and performance within each generation
        r_fee = Sortf(1, 1);
        VBR = Sortf(1, 2);
        Lactive = Sortf(1, 12);
        Zt = Sortf(1, 3);
        Wmt = Sortf(1, 4);
        Wpslab = Sortf(1, 5);
        Wnslab = Sortf(1, 6);
        Wnoffset = Sortf(1, 7);
        Wpbody = Sortf(1, 8);
        Wnbody = Sortf(1, 9);
        Wpplus_inner = Sortf(1, 10);
        Wnplus_inner = Sortf(1, 11);
        
        fprintf('************* FoM @ generation %.0f = %f , iEmper = %d ************\n',gen, SortOptM(1, 1), iEmper);
        fprintf('    r_fee = %f [1]\n', r_fee);
        fprintf('    VBR = %f [V]\n', VBR);
        fprintf('    Lactive = %f [um]\n', Lactive*1e6);
        fprintf('    Zt = %f [ohm]\n', Zt);
        fprintf('    Wmt = %f [um]\n', Wmt * 1e6);
        fprintf('    Wpslab = %f [um]\n', Wpslab * 1e6);
        fprintf('    Wnslab = %f [um]\n', Wnslab * 1e6);
        fprintf('    Wnoffset = %f [um]\n', Wnoffset * 1e6);
        fprintf('    Wpbody = %f [um]\n', Wpbody * 1e6);
        fprintf('    Wnbody = %f [um]\n', Wnbody * 1e6);
        fprintf('    Wpplus_inner = %f [um]\n', Wpplus_inner * 1e6);
        fprintf('    Wnplus_inner = %f [um]\n', Wnplus_inner * 1e6);
        fprintf('    the best FoM = %f \n', SortOptM(1, 1));
        fprintf('    the operating frequency of the best FoM = %f [GHz]\n', SortOptM(1, 2));
        fprintf('    the ER of the bset FoM = %f [dB]\n', SortOptM(1, 3));
        fprintf('    the IL of the bset FoM = %f [dB]\n', SortOptM(1, 4));
        fprintf('    the VpiLpi of the best FoM = %f [V-cm]\n', SortOptM(1, 5));
    end

    %% plot the evolution curve
    trace(end);
    figure('Units', 'centimeters', 'Position', [20, 10, 8, 6.486]); set(gca, 'FontSize', 9); 
    plot(trace);
    
    xlabel('Generation', 'fontweight', 'bold', 'FontSize', 12);    
    ylabel('Fitness Function', 'fontweight', 'bold', 'FontSize', 12);    
    title('Evolution Curve');
    set(gca, 'FontWeight', 'bold', 'LineWidth', 2);
    savefig(strcat(pwd, '\\', folderName, '\EvolutionCurve_theOptimized', num2str(optNum), '.fig'));
end

function results = Fitness (numericalFolder, ER_min, BW_min, X, f_np, i_discrete, Wrib_sweep, Hrib_sweep, Hslab_sweep, wl_sweep, Vpp)
    %% Local Params
    wl = 1.31e-6;
    FSR = 20e-9;
    T = 300;
    Zs = 50;    
    sigma_elec = 5.96e7;    % conductivity of metal traces, [S/m] or [1/(ohm*m)]
    sigma_SOI = 1/8.5e-2;     % conductivity of SOI unprocessed silicon [S/m]
    sigma_sub = 1/12e-2;   % conductivity of substrate, [S/m]
    t = 0.5e-6;       % thickness of metal traces, [m]
    t_MH = 1e-6;        % distance between metral trace lower y and rib waveguide higher y, [m]
    t_BOX = 2e-6;       % depth of burried oxide, [m]
    t_sub = 725e-6;     % depth of the substrate, [m]
    Hrib = 0.22e-6;        % rig waveguide height, [m]
    Hslab = 0.06e-6;   % height of the slab, [m]
    Wrib = 0.38e-6;         % rib waveguide width, [m]

    NA = 5e23;      % per m^3
    ND = 5e23;      % per m^3
    NAbody = 3e25;  % per m^3
    NDbody = 3e25;  % per m^3
    NAplus = 3e26;  % per m^3
    NDplus = 3e26;  % per m^3

    % Wgnd = 50e-6;
    Wmt = 30e-6;
    Wcontact = 1.8e-6;        % width of the highly p/n-doped rib contact region, [m]
    Wpplus_inner = 0.235e-6;      % width of the highly p-doped rib inner region, [m]
    Wpplus_outer = 0.2e-6;      % width of the highly p-doped rib outer region, [m]
%     Wpplus = Wpplus_inner + Wcontact + Wpplus_outer;
    Wnplus_inner = 0.235e-6;      % width of the highly n-doped rib inner region, [m]
    Wnplus_outer = 0.2e-6;      % width of the highly n-doped rib outer region, [m]
%     Wnplus = Wnplus_inner + Wcontact + Wnplus_outer;
    pts = 380;   % # of points in waveguide along x direction

    Vs = 1;         % RF driving signal, can be any, it will be reduced in the derivation of m
    f = 0.1:0.1:100; % GHz
    
    %% Parameters    
    r_fee = f_np(1);
    VBR = f_np(2);
    Zt = f_np(3);      % On Chip Termination Resistance
    Wmt = f_np(4);           % Width of the Signal Metal Trace
    Wpslab = f_np(5);
    Wnslab = f_np(6);
    Wnoffset = f_np(7);
    Wpbody = f_np(8);
    Wnbody = f_np(9);
    Wpplus_inner = f_np(10);
    Wnplus_inner = f_np(11);
    a = round((Wrib + Wpslab + Wnslab + Wpbody + Wnbody + Wpplus_inner + Wnplus_inner + 0.9e-6)/1e-9) * 1e-9;
    b = round((a + 2 * Wmt)/1e-9) * 1e-9;
    Lactive = f_np(12);
    
    N = 1500;     % # of points in active phase shifter diode region along propagation direction
    
    %% FOM
    [fee, gamma_fee, gammat_fee, f3dB_eo, SEE11_dB] = RF_analysis_all (numericalFolder, Wrib_sweep, Hrib_sweep, Hslab_sweep, wl_sweep, wl, r_fee, f, VBR, T, sigma_elec, sigma_SOI, sigma_sub, t, a, b, t_MH, Hslab, t_BOX, t_sub, NA, ND, NAbody, NDbody, NAplus, NDplus, Wpslab, Wnslab, Wpbody, Wnbody, Wcontact, Wpplus_inner, Wnplus_inner, Wpplus_outer, Wnplus_outer, Hrib, Wrib, Wnoffset, Lactive, Zs, Zt, Vs, pts);
    [VpiLpi, IL, ER, Vpp_y_ee] = FoM_y (numericalFolder, Wrib_sweep, Hrib_sweep, Hslab_sweep, wl_sweep, VBR, Vpp, Lactive, FSR, N, wl, Hrib, Wrib, Hslab, Wnoffset, Wpslab, Wnslab, Wpbody, Wnbody, NA, ND, NAbody, NDbody, pts, T, gamma_fee, gammat_fee);
    
    %% Constraints
    D = size(X, 2);   % # of input, i.e. the number of gene within a chromesome
    dX = X(1,:) - X(2,:);
    % iwhile = 0;
    % "NOT-Allowed Condition"
    % while ER < ER_min || sum(SEE11_dB > -10) > 0 || sum(diff(Vpp_y_ee) < 0) > 0 || isnan(VpiLpi) || (Wrib/2 + Wpslab + Wpbody) < 0.7e-6 || (Wrib/2 + Wnslab + Wnbody) < 0.7e-6 || c >= 175e-6 
    while fee < BW_min || ER < ER_min || sum(diff(Vpp_y_ee) < 0) > 0 || isnan(VpiLpi) || (Wrib/2 + Wpslab + Wpbody) < 0.7e-6 || (Wrib/2 + Wnslab + Wnbody) < 0.7e-6
        f_np = rand(1, D).* dX + X(2,:); % get father input matrix randomly
        %%%%%% need to be with steps of 5 nm
        f_np(i_discrete: end) = round(f_np(i_discrete: end) / 5e-9) * 5e-9;
        
        %% Parameters    
        r_fee = f_np(1);
        VBR = f_np(2);
        Zt = f_np(3);      % On Chip Termination Resistance
        Wmt = f_np(4);           % Width of the Signal Metal Trace
        Wpslab = f_np(5);
        Wnslab = f_np(6);
        Wnoffset = f_np(7);
        Wpbody = f_np(8);
        Wnbody = f_np(9);
        Wpplus_inner = f_np(10);
        Wnplus_inner = f_np(11);
        a = round((Wrib + Wpslab + Wnslab + Wpbody + Wnbody + Wpplus_inner + Wnplus_inner + 0.9e-6)/1e-9) * 1e-9;
        b = round((a + 2 * Wmt)/1e-9) * 1e-9;
        Lactive = f_np(12);
        
        %% FOM for Constraints of While loop until break
        [fee, gamma_fee, gammat_fee, ~, SEE11_dB] = RF_analysis_all (numericalFolder, Wrib_sweep, Hrib_sweep, Hslab_sweep, wl_sweep, wl, r_fee, f, VBR, T, sigma_elec, sigma_SOI, sigma_sub, t, a, b, t_MH, Hslab, t_BOX, t_sub, NA, ND, NAbody, NDbody, NAplus, NDplus, Wpslab, Wnslab, Wpbody, Wnbody, Wcontact, Wpplus_inner, Wnplus_inner, Wpplus_outer, Wnplus_outer, Hrib, Wrib, Wnoffset, Lactive, Zs, Zt, Vs, pts);
        [VpiLpi, IL, ER, Vpp_y_ee] = FoM_y (numericalFolder, Wrib_sweep, Hrib_sweep, Hslab_sweep, wl_sweep, VBR, Vpp, Lactive, FSR, N, wl, Hrib, Wrib, Hslab, Wnoffset, Wpslab, Wnslab, Wpbody, Wnbody, NA, ND, NAbody, NDbody, pts, T, gamma_fee, gammat_fee);
        % fprintf('  while done\n');
    end
    % FoM = fee;    % [GHz]     % to maximize the bandwidth when sortOption = 'descend', leading the largest fom @ first column
    FoM = max(SEE11_dB(f <= fee));      % to minimize the the maximum value of S11 within the bandwidth when sortOption = 'ascend', leading to the smallest fom @ first column
    % results = [FoM, f3dB_eo, ER, IL, VpiLpi, f_np];
    results = [FoM, fee, ER, IL, VpiLpi, f_np];
end

function [VpiLpi, IL, ER, Vpp_y_ee, del_l, VpiLpi_head] = FoM_y (numericalFolder, Wrib_sweep, Hrib_sweep, Hslab_sweep, wl_sweep, VBR, Vpp, Lactive, FSR, N, wl, Hrib, Wrib, Hslab, Wnoffset, Wpslab, Wnslab, Wpbody, Wnbody, NA, ND, NAbody, NDbody, pts, T, gamma_fee, gammat_fee)
    y = linspace(0, Lactive, N); dy = gradient(y);
    k0 = 2 * pi / wl;
    [Neff2, Neff1, Del_alpha2, Del_alpha1, Vpp_y_ee] = SSLV_FCIE (numericalFolder, Wrib_sweep, Hrib_sweep, Hslab_sweep, wl_sweep, Vpp, Lactive, y, wl, Hrib, Wrib, Hslab, Wnoffset, Wpslab, Wnslab, Wpbody, Wnbody, NA, ND, NAbody, NDbody, pts, T, gamma_fee, gammat_fee, VBR);
%     figure; plot(y*1e6, Vpp_y_ee); ylabel('Vpp(y)_e_e [V]'); xlabel('y [um]');
    VpiLpi = Vpp * Lactive * (wl * 100) / 2 / sum((Neff2 - Neff1) .* dy);
    VpiLpi_head = (wl * 100) / 2 / (Neff2(end) - Neff1(end)) * Vpp;
    
    [~, n1] = min(abs(Wrib_sweep - Wrib));
    [~, n2] = min(abs(Hrib_sweep - Hrib));
    [~, n3] = min(abs(Hslab_sweep - Hslab));
    idxstr = num2str(n1) + "_" + num2str(n2);
    load(pwd + "\\" + numericalFolder + "\neff_channel_" + idxstr + ".mat");
    neff0 = interp1(wl_sweep, conj(neff), wl); % neff0 = conj(neff(n4));
    Ng = interp1(wl_sweep, real(ng), wl); % Ng = real(ng(n4));
    
    idxstr = num2str(n1) + "_" + num2str(n2) + "_" + num2str(n3);
    load(pwd + "\\" + numericalFolder + "\neff_rib_" + idxstr + ".mat");
    neff0_rib = interp1(wl_sweep, conj(neff), wl); % neff0_rib = conj(neff(n4));
    
    del_l = wl^2 / Ng / FSR;        % Extra strip waveguide length for the specific FSR
    del_l = (floor(real(neff0) * del_l / wl) + 0.25) / real(neff0) * wl;    % Corrected extra strip waveguide length for additional 90 degree phase shift
    %% The normalized power transmission for the case of 1:1 power split
    % Tmax = max([0.25 * abs(exp(-1i * k0 * sum(Neff2 .* dy) - sum(100 * Del_alpha2 .* dy)/2 - 1i * k0 * neff0 * del_l) + exp(-1i * k0 * sum(Neff1 .* dy)  - sum(100 * Del_alpha1 .* dy)/2)) ^ 2, 0.25 * abs(exp(-1i * k0 * sum(Neff1 .* dy) - sum(100 * Del_alpha1 .* dy)/2 - 1i * k0 * neff0 * del_l) + exp(-1i * k0 * sum(Neff2 .* dy) - sum(100 * Del_alpha2 .* dy)/2)) ^ 2]);
    % Tmin = min([0.25 * abs(exp(-1i * k0 * sum(Neff2 .* dy) - sum(100 * Del_alpha2 .* dy)/2 - 1i * k0 * neff0 * del_l) + exp(-1i * k0 * sum(Neff1 .* dy)  - sum(100 * Del_alpha1 .* dy)/2)) ^ 2, 0.25 * abs(exp(-1i * k0 * sum(Neff1 .* dy) - sum(100 * Del_alpha1 .* dy)/2 - 1i * k0 * neff0 * del_l) + exp(-1i * k0 * sum(Neff2 .* dy) - sum(100 * Del_alpha2 .* dy)/2)) ^ 2]);
    
    %% Insertion Loss and Extinction Ratio
    % IL = -10 * log10(Tmax);    IL = IL + 20 / log(10) * k0 * abs(imag(neff0_rib)) * Lactive;
    % ER = 10 * log10(Tmax / Tmin);
    alpha0_rib = k0 * abs(imag(neff0_rib));
    alpha2 = alpha0_rib +  100 * Del_alpha2 / 2;
    alpha1 = alpha0_rib +  100 * Del_alpha1 / 2;
    
    % Considering segmented lossy TL, Vpp(y)
    Eout1 = 1/2 * (exp(-1i * k0 * sum(Neff2 .* dy) - sum(alpha2 .* dy) - 1i * k0 * neff0 * del_l) + exp(-1i * k0 * sum(Neff1 .* dy) - sum(alpha1 .* dy)));
    Eout2 = 1/2 * (exp(-1i * k0 * sum(Neff1 .* dy) - sum(alpha1 .* dy) - 1i * k0 * neff0 * del_l) + exp(-1i * k0 * sum(Neff2 .* dy) - sum(alpha2 .* dy)));
    
    % Considering uniform TL, lossless Vpp is constant
    % Eout1 = 1/2 * (exp(-1i * k0 * Neff2(end) * Lactive - alpha2(end) * Lactive - 1i * k0 * neff0 * del_l) + exp(-1i * k0 * Neff1(end) * Lactive - alpha1(end) * Lactive));
    % Eout2 = 1/2 * (exp(-1i * k0 * Neff1(end) * Lactive - alpha1(end) * Lactive - 1i * k0 * neff0 * del_l) + exp(-1i * k0 * Neff2(end) * Lactive - alpha2(end) * Lactive));
    
    Tmax = max([Eout1 * conj(Eout1), Eout2 * conj(Eout2)]);
    Tmin = min([Eout1 * conj(Eout1), Eout2 * conj(Eout2)]);
    
    %% Insertion Loss and Extinction Ratio
    IL = -10 * log10(Tmax);
    ER = 10 * log10(Tmax / Tmin);
end

function [fee, gamma_fee, gammat_fee, f3dB_eo, SEE11_dB] = RF_analysis_all_figure (numericalFolder, figPath, Wrib_sweep, Hrib_sweep, Hslab_sweep, wl_sweep, wl, r_fee, f, VBR, T, sigma_elec, sigma_SOI, sigma_sub, t, a, b, c, t_MH, Hslab, t_BOX, t_sub, NA, ND, NAbody, NDbody, NAplus, NDplus, Wpslab, Wnslab, Wpbody, Wnbody, Wcontact, Wpplus_inner, Wnplus_inner, Wpplus_outer, Wnplus_outer, Hrib, Wrib, Wnoffset, Lactive, Zs, Zt, Vs, pts)
    %%%%%%%%%%%%%%%%%%%%%%% PN junction & RF analysis  %%%%%%%%%%%%%%%%%%
    [Z0, gamma, Cj, Rj, R, L, G, C] = RFCharacteristic_CPS (f .* 1e9, VBR, T, sigma_elec, sigma_SOI, sigma_sub, t, a, b, c, t_MH, Hslab, t_BOX, t_sub, NA, ND, NAbody, NDbody, NAplus, NDplus, Wpslab, Wnslab, Wpbody, Wnbody, Wcontact, Wpplus_inner, Wnplus_inner, Wpplus_outer, Wnplus_outer, Hrib, Wrib, Wnoffset);

    %%%%%%%%%%%%%%%%%%%%%%% RF S parameters  %%%%%%%%%%%%%%%%%%%%%%%
    [SEE11_dB, SEE21_dB] = FindS (Z0, gamma, Lactive, Zs, Zt);
    
    %% neffe & nge
    c0 = 299792458;
    neffe = imag(gamma)./(2*pi.*f.*1e9./c0); Attenuation = 2*10/log(10) *real(gamma)/1e3; % dB/mm
    omega = 2 * pi .*f .* 1e9;
    domega = gradient(omega); 
    nge = neffe + omega.*(gradient(neffe))./(domega);
    %%%%%%%%%%%%%% EO modulation frequency response  %%%%%%%%%%%%%%%%%%%%%%%
    SEO21 = EO_response (numericalFolder, Wrib_sweep, Hrib_sweep, Hslab_sweep, wl_sweep, wl, Hrib, Wrib, Hslab, Wnoffset, Wpslab, Wnslab, Wpbody, Wnbody, NA, ND, NAbody, NDbody, pts, T, f.*1e9, Z0, gamma, Cj, Rj, Zs, Zt, Lactive, Vs);
    SEO21_dB = 20*log10(abs(SEO21));
    if isnan(SEO21_dB)
        % fprintf('f3dB_eo = 0.5 [GHz]\n');
        f3dB_eo = 0.5;
        fee = 0.1;
    else
        f3dB_eo = interp1(SEO21_dB, f, -3);
        fee = r_fee * f3dB_eo; 
    end
    [gamma_fee, gammat_fee] = FindParamAt_f_operation (fee*1e9, f.*1e9, Z0, gamma, Zt);
    
    %% IMEC case for comparing
    [Z0_IMEC, gamma_IMEC, Cj_IMEC, Rj_IMEC, R_IMEC, L_IMEC, G_IMEC, C_IMEC] = RFCharacteristic_CPS (f .* 1e9, 2, T, sigma_elec, sigma_SOI, sigma_sub, t, 5.5e-6, 12.3e-6, t_MH, Hslab, t_BOX, t_sub, NA, ND, NAbody, NDbody, NAplus, NDplus, 0.3e-6, 0.3e-6, 0.975e-6, 0.975e-6, Wcontact, Wpplus_inner, Wnplus_inner, Wpplus_outer, Wnplus_outer, Hrib, Wrib, 0e-6);
    
    [S11dB_ee_IMEC, S21dB_ee_IMEC] = FindS (Z0_IMEC, gamma_IMEC, 1500e-6, 50, 36);
    neffe_IMEC = imag(gamma_IMEC)./(2*pi.*f.*1e9./c0); 
    Attenuation_IMEC = 2*10/log(10) *real(gamma_IMEC)/1e3; % dB/mm
    nge_IMEC = neffe_IMEC + omega.*(gradient(neffe_IMEC))./(domega);
    SEO21_IMEC = EO_response (numericalFolder, Wrib_sweep, Hrib_sweep, Hslab_sweep, wl_sweep, wl, Hrib, Wrib, Hslab, 0e-6, 0.3e-6, 0.3e-6, 0.975e-6, 0.975e-6, NA, ND, NAbody, NDbody, pts, T, f.*1e9, Z0_IMEC, gamma_IMEC, Cj_IMEC, Rj_IMEC, 50, 36, 1500e-6, 1);
    SEO21_dB_IMEC = 20*log10(abs(SEO21_IMEC));
    
    %% Plot and Save
    % Reff
    figureTemplate(transpose([f; R; f; R_IMEC]), 'Frequency (GHz)', 'R_e_f_f (\Omega/m)', {'opt', 'imec'}, strcat(figPath, 'Reff'))
    
    % Leff
    figureTemplate(transpose([f; L; f; L_IMEC]), 'Frequency (GHz)', 'L_e_f_f (H/m)', {'opt', 'imec'}, strcat(figPath, 'Leff'))
    
    % Geff
    figureTemplate(transpose([f; G; f; G_IMEC]), 'Frequency (GHz)', 'G_e_f_f (S/m)', {'opt', 'imec'}, strcat(figPath, 'Geff'))
    
    % Ceff
    figureTemplate(transpose([f; C; f; C_IMEC]), 'Frequency (GHz)', 'C_e_f_f (S/m)', {'opt', 'imec'}, strcat(figPath, 'Ceff'))
    
    % real(Z0)
    figureTemplate(transpose([f; real(Z0); f; real(Z0_IMEC)]), 'Frequency (GHz)', 'Re\{Z_0\} (\Omega)', {'opt', 'imec'}, strcat(figPath, 'Z0_real'))
    
    % imag(Z0)
    figureTemplate(transpose([f; imag(Z0); f; imag(Z0_IMEC)]), 'Frequency (GHz)', 'Im\{Z_0\} (\Omega)', {'opt', 'imec'}, strcat(figPath, 'Z0_imag'))
    
    % neffe
    figureTemplate(transpose([f; neffe; f; neffe_IMEC]), 'Frequency (GHz)', 'neffe', {'opt', 'imec'}, strcat(figPath, 'neffe'))
    
    % nge
    figureTemplate(transpose([f; nge; f; nge_IMEC]), 'Frequency (GHz)', 'nge', {'opt', 'imec'}, strcat(figPath, 'nge'))
    
    % attenuation
    figureTemplate(transpose([f; Attenuation; f; Attenuation_IMEC]), 'Frequency (GHz)', 'Attenuation (dB/mm)', {'opt', 'imec'}, strcat(figPath, 'Attenuation'))
    
    % SEE11_dB
    figureTemplate(transpose([f; SEE11_dB; f; S11dB_ee_IMEC]), 'Frequency (GHz)', 'S_E_E_1_1 (dB)', {'opt', 'imec'}, strcat(figPath, 'SEE11_dB'))
    
    % SEO21_dB
    figureTemplate(transpose([f; SEO21_dB; f; SEO21_dB_IMEC]), 'Frequency (GHz)', 'S_E_O_2_1', {'opt', 'imec'}, strcat(figPath, 'SEO21_dB'))
end

function [fee, gamma_fee, gammat_fee, f3dB_eo, SEE11_dB] = RF_analysis_all (numericalFolder, Wrib_sweep, Hrib_sweep, Hslab_sweep, wl_sweep, wl, r_fee, f, VBR, T, sigma_elec, sigma_SOI, sigma_sub, t, a, b, t_MH, Hslab, t_BOX, t_sub, NA, ND, NAbody, NDbody, NAplus, NDplus, Wpslab, Wnslab, Wpbody, Wnbody, Wcontact, Wpplus_inner, Wnplus_inner, Wpplus_outer, Wnplus_outer, Hrib, Wrib, Wnoffset, Lactive, Zs, Zt, Vs, pts)
    %........................................................ PN junction & RF analysis  ...................................................
    [Z0, gamma, Cj, Rj] = RFCharacteristic_CPS (f .* 1e9, VBR, T, sigma_elec, sigma_SOI, sigma_sub, t, a, b, t_MH, Hslab, t_BOX, t_sub, NA, ND, NAbody, NDbody, NAplus, NDplus, Wpslab, Wnslab, Wpbody, Wnbody, Wcontact, Wpplus_inner, Wnplus_inner, Wpplus_outer, Wnplus_outer, Hrib, Wrib, Wnoffset);

    %........................................................ RF S parameters  ...................................................
    [SEE11_dB, SEE21_dB] = FindS (Z0, gamma, Lactive, Zs, Zt);
    SEO21 = EO_response (numericalFolder, Wrib_sweep, Hrib_sweep, Hslab_sweep, wl_sweep, wl, Hrib, Wrib, Hslab, Wnoffset, Wpslab, Wnslab, Wpbody, Wnbody, NA, ND, NAbody, NDbody, pts, T, f.*1e9, Z0, gamma, Cj, Rj, Zs, Zt, Lactive, Vs);
    SEO21_dB = 20*log10(abs(SEO21));
    if isnan(SEO21_dB)
        % fprintf('f3dB_eo = 0.5 [GHz]\n');
        f3dB_eo = 0.5;
        fee = 0.1;
    else
        f3dB_eo = interp1(SEO21_dB, f, -3);
        fee = r_fee * f3dB_eo; 
    end
    [gamma_fee, gammat_fee] = FindParamAt_f_operation (fee*1e9, f.*1e9, Z0, gamma, Zt);
end

function  [Neff2, Neff1, Del_alpha2, Del_alpha1, Vpp_y_ee] = SSLV_FCIE (numericalFolder, Wrib_sweep, Hrib_sweep, Hslab_sweep, wl_sweep, Vpp, Lactive, y, wl, Hrib, Wrib, Hslab, Wnoffset, Wpslab, Wnslab, Wpbody, Wnbody, NA, ND, NAbody, NDbody, pts, T, gamma_fee, gammat_fee, VBR)          % Small Signal Lossy Voltage_Free Carrier Induced Effect
%     Vs_ee = Vpp/2 * (1 + gammas_3dBeo * gammat_3dBeo * exp(-2 * gamma_fee * Lactive)) / ((gammas_3dBeo + 1)/2) / (1 + gammat_3dBeo * exp(-2*gamma_fee*Lactive));
    Vpp_y_ee = abs( Vpp * (exp(gamma_fee*y) .* (1 + gammat_fee * exp(-2 * gamma_fee * y))) ./ (exp(gamma_fee*Lactive) * (1 + gammat_fee * exp(-2*gamma_fee*Lactive))) );
%     Vpp_y_eo = abs( Vpp * (exp(i*beta1_3dBeo*y) .* (1 + gammat_3dBeo * exp(-2 * gamma_fee * y))) ./ (exp(i*beta1_3dBeo*Lactive) * (1 + gammat_3dBeo * exp(-2*gamma_3dBeo*Lactive))) );
    Neff2 = []; Neff1 = []; Del_alpha2 = []; Del_alpha1 = [];
    for iVpp_y_ee = 1:length(Vpp_y_ee)
        [neff2, del_alpha2] = neff_alpha_V_CPS (numericalFolder, Wrib_sweep, Hrib_sweep, Hslab_sweep, wl_sweep, wl, Hrib, Wrib, Hslab, Wnoffset, Wpslab, Wnslab, Wpbody, Wnbody, NA, ND, NAbody, NDbody, pts, T, VBR + Vpp_y_ee(iVpp_y_ee)/4);
        [neff1, del_alpha1] = neff_alpha_V_CPS (numericalFolder, Wrib_sweep, Hrib_sweep, Hslab_sweep, wl_sweep, wl, Hrib, Wrib, Hslab, Wnoffset, Wpslab, Wnslab, Wpbody, Wnbody, NA, ND, NAbody, NDbody, pts, T, VBR - Vpp_y_ee(iVpp_y_ee)/4);
        Neff2 = [Neff2, neff2];
        Neff1 = [Neff1, neff1];
        Del_alpha2 = [Del_alpha2, del_alpha2];
        Del_alpha1 = [Del_alpha1, del_alpha1];
    end
end

function [gamma_3dBeo, gammat_3dBeo] = FindParamAt_f_operation (fee, f, Z0, gamma, Zt)         %%%%% f, f3dB_eo need to * 1e9
    Z0_3dBeo = interp1(f, Z0, fee);
    gamma_3dBeo = interp1(f, gamma, fee);
    gammat_3dBeo = (Zt - Z0_3dBeo) / (Zt + Z0_3dBeo);
end

function [S11dB, S21dB] = FindS (Z0, gamma, Lactive, Zs, Zt)
    gammas = (Z0 - Zs) ./ (Z0 + Zs);
    gammat = (Zt - Z0) ./ (Zt + Z0);
    S11 = (gammas + gammat .* exp(-2*gamma*Lactive)) ./ (1 + gammas .* gammat .* exp(-2*gamma*Lactive));
    S11dB = 20.*log10(abs(S11));
    S21 = (1+gammas) .* (1+gammat) .* exp(-gamma*Lactive) ./ (1 + gammas .* gammat .* exp(-2*gamma*Lactive));
    S21dB = 20.*log10(abs(S21));
end

function [SEO21, phaseplus, phaseminus]= EO_response (numericalFolder, Wrib_sweep, Hrib_sweep, Hslab_sweep, wl_sweep, wl, Hrib, Wrib, Hslab, Wnoffset, Wpslab, Wnslab, Wpbody, Wnbody, NA, ND, NAbody, NDbody, pts, T, f, Z0, gamma, Cj, Rj, Zs, Zt, Lactive, Vs)
    % f need to * 1e9
    c0 = 299792458; % [m/s]
    
    %% load neff from neff_rib_FT
    [~, n1] = min(abs(Wrib_sweep - Wrib));
    [~, n2] = min(abs(Hrib_sweep - Hrib));
    [~, n3] = min(abs(Hslab_sweep - Hslab));
    idxstr = num2str(n1) + "_" + num2str(n2) + "_" + num2str(n3);
    load(pwd + "\\" + numericalFolder + "\neff_rib_" + idxstr + ".mat");
    neff_rib_sweep = interp1(wl_sweep, conj(neff), [wl; wl + 10e-9; wl - 10e-9]);
    
    %% ngo @ Vr = 0V
    % lambda @ wl
    [neff_V, del_alpha_V] = neff_alpha_V_CPS (numericalFolder, Wrib_sweep, Hrib_sweep, Hslab_sweep, wl_sweep, wl, Hrib, Wrib, Hslab, Wnoffset, Wpslab, Wnslab, Wpbody, Wnbody, NA, ND, NAbody, NDbody, pts, T, 0);
    k0_wl = 2 * pi / wl;
    neff_V = neff_V + 1i * (abs(imag(neff_rib_sweep(1))) + del_alpha_V * 100 / 2 / k0_wl);
        
    % lambda @ wl + 10nm
    [neff_V_wl2, del_alpha_V_wl2] = neff_alpha_V_CPS (numericalFolder, Wrib_sweep, Hrib_sweep, Hslab_sweep, wl_sweep, wl + 10e-9, Hrib, Wrib, Hslab, Wnoffset, Wpslab, Wnslab, Wpbody, Wnbody, NA, ND, NAbody, NDbody, pts, T, 0);
    k0_wl2 = 2 * pi / (wl + 10e-9);
    neff_V_wl2 = neff_V_wl2 + 1i * (abs(imag(neff_rib_sweep(2))) + del_alpha_V_wl2 * 100 / 2 / k0_wl2);
        
    % lambda @ wl - 10nm
    [neff_V_wl1, del_alpha_V_wl1] = neff_alpha_V_CPS (numericalFolder, Wrib_sweep, Hrib_sweep, Hslab_sweep, wl_sweep, wl - 10e-9, Hrib, Wrib, Hslab, Wnoffset, Wpslab, Wnslab, Wpbody, Wnbody, NA, ND, NAbody, NDbody, pts, T, 0);
    k0_wl1 = 2 * pi / (wl - 10e-9);
    neff_V_wl1 = neff_V_wl1 + 1i * (abs(imag(neff_rib_sweep(3))) + del_alpha_V_wl1 * 100 / 2 / k0_wl1);
    
    % ngo
    ngo = real(neff_V - wl * (neff_V_wl2 - neff_V_wl1) / (20e-9));

    gammas = (Z0 - Zs) ./ (Z0 + Zs);
    gammat = (Zt - Z0) ./ (Zt + Z0);
    omega = 2 .* pi .* f;
    beta1 = -1i .* (gamma - 1i .* omega .* ngo ./ c0);
    beta2 = -1i .* (gamma + 1i .* omega .* ngo ./ c0);
    Vplus = Vs .* (1 + gammas) ./ 2 ./ (exp(1i*beta1*Lactive) + gammas .* gammat .* exp(-1i*beta2*Lactive)); 
    phaseplus = phaseCoeff(beta1, Lactive, 'plus');
    phaseminus = phaseCoeff(beta2, Lactive, 'minus');
    Vavg = Vplus .* (phaseplus + gammat .* phaseminus);
    Vdep = Vavg ./ (1 + 1i .* omega.*Rj .* Cj);
    SEO21 = abs( Vdep ./ Vdep(1));
end

function [phase, phi] = phaseCoeff (beta, Lactive, sign)
    if strcmp(sign, 'plus')
        phi = beta .* Lactive ./ 2;
    else
        phi = -beta .* Lactive ./2;
    end
    phase = exp(1i .* phi) .* sin(phi) ./ (1i .* phi);
end

function figureTemplate(data, xlabelStr, ylabelStr, legendStr_cell, figureName, xlimVector, ylimVector)
    %% plot
    figure('Units', 'centimeters', 'Position', [20, 10, 8, 6.486]);
    % figure('Units', 'centimeters', 'Position', [20, 10, 20, 10]);
    % jet, rand(~, 3), hsv, hot, cool, spring, summer, autumn, winter, lines,
    % gray, bone, copper, pink
    colorSequence = [
        1, 0, 0;
        1, 140/255, 0;
        0, 0.5, 0;
        0, 0, 1;
        0.75, 0, 0.75;
        0, 0, 0
        ];
    set(gca, 'ColorOrder', colorSequence, 'NextPlot', 'replacechildren');
    set(gca, 'FontSize', 9); 
    
    %%
    markStr_cell = {'-', '--', '-.', '.'};
    n_color = size(colorSequence, 1);
    xyDataStr = strcat("data(:, 1), data(:, 2), markStr_cell{1}");
    if size(data, 2) >= 3
        for n = 3:2:size(data, 2)
            xyDataStr = strcat(xyDataStr, ", data(:, ", num2str(n), "), data(:, ", num2str(n + 1), "), markStr_cell{", num2str(ceil((n + 1) / 2 / n_color)) , "}");
        end
    end
    
    eval(strcat("plot(", xyDataStr, ", 'LineWidth', 1);"));
    % grid on;
    if nargin == 7
        ylim(ylimVector);
        xlim(xlimVector);
    end
    if nargin == 6
        xlim(xlimVector);
    end
    % set(gca,'YTick', [-70:5:0]);

    %%
    set(gca, 'FontWeight', 'bold', 'LineWidth', 2);

    %%
    ylabel(ylabelStr, 'fontweight', 'bold', 'FontSize', 12);
    xlabel(xlabelStr, 'fontweight', 'bold', 'FontSize', 12);
    % txt = {'applied voltage @', 'both arms ='};
    % text(1300, -50, txt, 'FontWeight', 'bold', 'FontSize', 9);
    
    if length(legendStr_cell) > 0
        legend(legendStr_cell, 'FontSize', 9, 'Box', 'off');
    end
%     title('channel4   channel3   channel2   channel1');
    savefig(strcat(figureName,'.fig'));
end

%% doping vs resistivity
function NA = Doping_p (Rsp, t)
    rhop = Rsp * t;  % Rsp: [ohm/square], rhop: [ohm*m]
  %% cleanroom.byu.edu/ResistivityCal, Boron I.I. doping
    M = [1E12, 14667.262500697669;...
        2e12, 7334.3074668356185;...
        3e12, 4889.927087022465;...
        4e12, 3667.7102733442443;...
        5e12, 2934.365635920998;...
        6e12, 2445.4601526215956;...
        7e12, 2096.2358218597333;...
        8e12, 1834.3131803545389;...
        9e12, 1630.5922829017052;...
        1E13, 1467.6130226932708;...
        2e13, 734.1605785943417;...
        3e13, 489.6439489075054;...
        4e13, 367.37169384563;...
        5e13, 294.00072283249114;...
        6e13, 245.08199920075117;...
        7e13, 210.13684491389827;...
        8e13, 183.92567879490377;...
        9e13, 163.53749497737368;...
        1E14, 147.2256168021463;...
        2e14, 73.79819816655328;...
        3e14, 49.30538454654703;...
        4e14, 37.051678632073724;...
        5e14, 29.6954663078232;...
        6e14, 24.788841344326187;...
        7e14, 21.282429079816335;...
        8e14, 18.651415388971305;...
        9e14, 16.604170143963735;...
        1e15, 14.965676972314505;...
        2e15, 7.579908648305307;...
        3e15, 5.109080787309241;...
        4e15, 3.8698450424845046;...
        5e15, 3.1242150676530103;...
        6e15, 2.6258280446610405;...
        7e15, 2.268957205168585;...
        8e15, 2.0006719602343748;...
        9e15, 1.7915300674070833;...
        1E16, 1.6238443702134566;...
        2e16, 0.8616982987851544;...
        3e16, 0.6007793658993279;...
        4e16, 0.4668833077437573;...
        5e16, 0.3848097488327641;...
        6e16, 0.32916413932536687;...
        7e16, 0.28887714529663105;...
        8e16, 0.25832187283212754;...
        9e16, 0.23432669984878876;...
        1E17, 0.21496536080345086;...
        2e17, 0.12511746716382996;...
        3e17, 0.09321100328175008;...
        4e17, 0.07634129495480432;...
        5e17, 0.06568624199523963;...
        6e17, 0.058237674979408;...
        7e17, 0.05267784309720679;...
        8e17, 0.04833354819073814;...
        9e17, 0.044822807002399274;...
        1E18, 0.04191163444675014;...
        2e18, 0.026966103247715024;...
        3e18, 0.02071543061160277;...
        4e18, 0.01708643063417176;...
        5e18, 0.014656473723778948;...
        6e18, 0.012892019382870181;...
        7e18, 0.01154155651659908;...
        8e18, 0.010468880767556137;...
        9e18, 0.009592965508561903;...
        1E19, 0.00886221011340648;...
        2e19, 0.005131728638834896;...
        3e19, 0.0036579869149012435;...
        4e19, 0.0028561262015310857;...
        5e19, 0.002349211020946666;...
        6e19, 0.0019989859115629813;...
        7e19, 0.0017422817628892251;...
        8e19, 0.0015459975398086781;...
        9e19, 0.00139106420123108;...
        1e20, 0.0012657019138033899;...
        2e20, 0.0006897187930032605;...
        3e20, 0.0004998786019967727;...
        4e20, 0.0004094563399566657;...
        5e20, 0.0003577783126309449;...
        6e20, 0.00032423639614114494;...
        7e20, 0.00030011836259918087;...
        8e20, 0.00028128252654560214;...
        9e20, 0.00026562246738990046;...
        1e21, 0.00025201950291479263];
    
    %% Boron I.I.
    doping = 1e6 * M(:, 1);  % transfer from [cm^-3] to [m^-3]
    r = 0.01 * M(:, 2);      % transfer from [ohm-cm] to [ohm-m]
    
    %% interpl
    NA = 10 ^ interp1(r, log10(doping), rhop);
end

function ND = Doping_n (Rsn, t)
    rhon = Rsn * t; % Rsn: [ohm/square], rhon: [ohm-m]
    %% cleanroom.byu.edu/ResistivityCal, Phosphorus I.I. doping
    M = [1e12, 4415.312387249216;...
        2e12, 2208.0516252889915;...
        3e12, 1472.260794813711;...
        4e12, 1104.3494534905074;...
        5e12, 883.593966403182;...
        6e12, 736.4182459153325;...
        7e12, 631.2890861537179;...
        8e12, 552.4396063742955;...
        9e12, 491.11028238255386;...
        1e13, 442.0453159585842;...
        2e13, 221.2258953366559;...
        3e13, 147.6002720150266;...
        4e13, 110.77927061797217;...
        5e13, 88.68220465551408;...
        6e13, 73.94805219339818;...
        7e13, 63.42178267013413;...
        8e13, 55.5257379731432;...
        9e13, 49.38336630535094;...
        1e14, 44.4686935514395;...
        2e14, 22.338735736616144;...
        3e14, 14.952225669892737;...
        4e14, 11.2547527654003;...
        5e14, 9.03396836755867;...
        6e14, 7.552014950229166;...
        7e14, 6.492509980307877;...
        8e14, 5.697188698869662;...
        9e14, 5.078087610023568;...
        1e15, 4.582406466925789;...
        2e15, 2.3446428190337527;...
        3e15, 1.5936188312472996;...
        4e15, 1.2159178983143852;...
        5e15, 0.9881007516938989;...
        6e15, 0.8354771661910652;...
        7e15, 0.7259555395677811;...
        8e15, 0.643452105317738;...
        9e15, 0.5790114696983483;...
        1e16, 0.527248940778915;...
        2e16, 0.29052217421980503;...
        3e16, 0.20890178710676735;...
        4e16, 0.16691593198161894;...
        5e16, 0.14107609616679467;...
        6e16, 0.12344257457228096;...
        7e16, 0.11056980467025358;...
        8e16, 0.10071498770296652;...
        9e16, 0.09289934113086042;...
        1e17, 0.08652951863165105;...
        2e17, 0.05571655256990463;...
        3e17, 0.043882899033872075;...
        4e17, 0.037276332798897575;...
        5e17, 0.03292880659958998;...
        6e17, 0.02978892208221377;...
        7e17, 0.027381574619978873;...
        8e17, 0.025457601255549075;...
        9e17, 0.02387237860989364;...
        1e18, 0.022535527511173582;...
        2e18, 0.015296376795037384;...
        3e18, 0.012046447049756204;...
        4e18, 0.010088747307958466;...
        5e18, 0.008746434208670373;...
        6e18, 0.007755106254631488;...
        7e18, 0.0069865311094907704;...
        8e18, 0.006369761891436145;...
        9e18, 0.005861872543276224;...
        1e19, 0.005435145683486666;...
        2e19, 0.0032109478254829377;...
        3e19, 0.0023085709125624998;...
        4e19, 0.0018107291820831128;...
        5e19, 0.0014930022758197375;...
        6e19, 0.001271837287890109;...
        7e19, 0.0011086827741232424;...
        8e19, 0.0009831936158292054;...
        9e19, 0.0008835852987861998;...
        1e20, 0.000802546357126152;...
        2e20, 0.00042070536404033483;...
        3e20, 0.0002859354020328652;...
        4e20, 0.0002167940227303361;...
        5e20, 0.00017466969978011874;...
        6e20, 0.00014629489974523987;...
        7e20, 0.00012587374537441188;...
        8e20, 0.00011046899716362771;...
        9e20, 0.00009843223638040267;...
        1e21, 0.000088766503533662];
    %%
    doping = 1e6 * M(:, 1);  % transfer from [cm^-3] to [m^-3]
    r = 0.01 * M(:, 2);  % transfer from [ohm-cm] to [ohm-m]

    %%
    ND = 10 ^ interp1(r, log10(doping), rhon);
end